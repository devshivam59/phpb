# Quick Start Guide - Robo Trade Platform

## 🚀 Get Started in 5 Minutes

### Step 1: Extract Files
Extract the `robo-trade-platform.tar.gz` to your web server directory:
- **XAMPP**: `C:\xampp\htdocs\`
- **WAMP**: `C:\wamp\www\`
- **Linux**: `/var/www/html/`
- **cPanel**: `public_html/`

### Step 2: Configure Database
Edit `config/database.php` and update:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_NAME', 'robo_trade');
```

### Step 3: Run Installation
Open your browser and navigate to:
```
http://localhost/robo-trade-platform/install.php
```
or
```
http://yourdomain.com/install.php
```

The installer will:
- ✅ Create database
- ✅ Create all tables
- ✅ Set up admin account

### Step 4: Login
**Admin Panel**: `http://yourdomain.com/admin/`
- Admin ID: `admin001`
- Password: `admin123`

**User Panel**: `http://yourdomain.com/user/`
- Users must be created by admin

### Step 5: Security
1. **Delete** `install.php` file
2. **Change** admin password immediately
3. Update UPI details in `config/config.php`

## 📋 Admin Tasks

### Create a User
1. Login to admin panel
2. Go to **Users** → Click **Add User**
3. Fill details and submit
4. Share User ID and password with user

### Approve Deposit
1. Go to **Deposits** → Click **Pending**
2. View payment proof
3. Click **Approve** to add funds

### Approve Withdrawal
1. Go to **Withdrawals** → Click **Pending**
2. Verify bank details
3. Click **Approve** to process

### Create Trade
1. Go to **Trades** → Click **Add Trade**
2. Select user, enter symbol, type, quantity, price
3. Submit to create trade
4. Click **Close** to close open positions

## 📱 User Tasks

### Make Deposit
1. Login to user panel
2. Go to **Funds** → Click **Make Deposit**
3. Enter amount and payment details
4. Upload payment proof
5. Wait for admin approval

### Request Withdrawal
1. Update bank details in **Profile**
2. Go to **Funds** → Click **Request Withdrawal**
3. Enter amount
4. Wait for admin approval

### View Positions
1. Go to **Positions**
2. See all your trades
3. Filter by Open/Closed

## 🔧 Configuration

### UPI Payment Settings
Edit `config/config.php`:
```php
define('UPI_ID', 'your-upi-id@upi');
define('UPI_NAME', 'Your Business Name');
```

### Site Settings
```php
define('SITE_NAME', 'Your Trading Platform');
define('SITE_URL', 'https://yourdomain.com');
```

## 📊 Features

### User Panel
- ✅ Live market prices (Nifty, Bank Nifty, Sensex, Fin Nifty)
- ✅ Sector-wise stock view
- ✅ Deposit/Withdrawal management
- ✅ View trading positions
- ✅ Transaction history
- ✅ Profile & bank details management

### Admin Panel
- ✅ User management (create, edit, status)
- ✅ Deposit approval/rejection
- ✅ Withdrawal processing
- ✅ Manual trade entry & closing
- ✅ Balance management
- ✅ Activity logs

## 🆘 Troubleshooting

### White Screen
- Check `error_log` in Apache logs
- Enable `display_errors` in `php.ini`

### Database Connection Failed
- Verify credentials in `config/database.php`
- Ensure MySQL is running

### File Upload Error
- Check folder permissions: `chmod 777 uploads/`
- Verify `upload_max_filesize` in `php.ini`

### Live Prices Not Loading
- Check browser console for errors
- System uses fallback dummy data if API fails

## 📁 File Structure
```
robo-trade-platform/
├── config/          # Configuration files
├── includes/        # Common functions & API
├── admin/           # Admin panel
├── user/            # User panel
├── api/             # API endpoints
├── assets/          # CSS, JS, images
├── uploads/         # User uploads
├── install.php      # Installation script
└── README.md        # Full documentation
```

## 🔒 Security Checklist
- [ ] Delete `install.php`
- [ ] Change admin password
- [ ] Enable HTTPS (SSL)
- [ ] Set proper file permissions
- [ ] Update database password
- [ ] Disable `display_errors` in production
- [ ] Set up regular backups

## 📚 Documentation
- **Full Guide**: See `README.md`
- **Deployment**: See `DEPLOYMENT_GUIDE.md`

## 💡 Tips
- Test on localhost before production
- Keep regular database backups
- Monitor error logs
- Update PHP and MySQL regularly

## 🎯 Default Credentials
**Admin**: admin001 / admin123  
**⚠️ CHANGE IMMEDIATELY AFTER LOGIN!**

---

**Need Help?**
Check the full `README.md` and `DEPLOYMENT_GUIDE.md` for detailed instructions.

**Version**: 1.0.0

