UPLOADS DIRECTORY
==================

This directory stores user-uploaded files.

IMPORTANT: Set proper permissions after deployment:
chmod 755 uploads/
chmod 777 uploads/profiles/

The .htaccess file ensures only image files can be accessed directly.

