-- Add new columns to users table
ALTER TABLE users ADD COLUMN aadhar_number VARCHAR(12) DEFAULT NULL;
ALTER TABLE users ADD COLUMN pan_number VARCHAR(10) DEFAULT NULL;
ALTER TABLE users ADD COLUMN address TEXT DEFAULT NULL;
ALTER TABLE users ADD COLUMN dob DATE DEFAULT NULL;
ALTER TABLE users ADD COLUMN qr_code_image VARCHAR(255) DEFAULT NULL;
ALTER TABLE users ADD COLUMN theme_preference ENUM('light', 'dark') DEFAULT 'dark';
ALTER TABLE users ADD COLUMN design_theme VARCHAR(20) DEFAULT 'default';

-- Create registration_requests table
CREATE TABLE IF NOT EXISTS registration_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id_requested VARCHAR(50) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    dob DATE NOT NULL,
    pan_number VARCHAR(10) NOT NULL,
    aadhar_number VARCHAR(12) NOT NULL,
    bank_name VARCHAR(255) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    ifsc_code VARCHAR(20) NOT NULL,
    account_holder_name VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    admin_note TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    processed_by INT,
    UNIQUE KEY unique_email (email),
    UNIQUE KEY unique_phone (phone)
);
