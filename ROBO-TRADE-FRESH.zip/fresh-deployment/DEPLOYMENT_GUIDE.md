# Robo Trade Platform - Deployment Guide

## Quick Start Guide

### Option 1: Local Development (XAMPP/WAMP)

#### For Windows (XAMPP)
1. Download and install XAMPP from https://www.apachefriends.org/
2. Extract `robo-trade-platform.tar.gz` to `C:\xampp\htdocs\`
3. Start Apache and MySQL from XAMPP Control Panel
4. Open phpMyAdmin: http://localhost/phpmyadmin
5. Create a new database named `robo_trade`
6. Navigate to http://localhost/robo-trade-platform/install.php
7. Follow installation instructions
8. Login with default credentials

#### For Mac (MAMP)
1. Download and install MAMP from https://www.mamp.info/
2. Extract platform to `/Applications/MAMP/htdocs/`
3. Start MAMP servers
4. Follow same steps as XAMPP above

### Option 2: Linux Server (Ubuntu/Debian)

#### Step 1: Install Prerequisites
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Apache
sudo apt install apache2 -y

# Install MySQL
sudo apt install mysql-server -y

# Install PHP and extensions
sudo apt install php php-mysql php-curl php-gd php-mbstring php-xml -y

# Enable Apache modules
sudo a2enmod rewrite
sudo systemctl restart apache2
```

#### Step 2: Configure MySQL
```bash
# Secure MySQL installation
sudo mysql_secure_installation

# Login to MySQL
sudo mysql -u root -p

# Create database and user
CREATE DATABASE robo_trade;
CREATE USER 'robo_user'@'localhost' IDENTIFIED BY 'strong_password_here';
GRANT ALL PRIVILEGES ON robo_trade.* TO 'robo_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

#### Step 3: Deploy Application
```bash
# Extract platform files
cd /var/www/html
sudo tar -xzf robo-trade-platform.tar.gz
sudo chown -R www-data:www-data robo-trade-platform
sudo chmod -R 755 robo-trade-platform

# Set upload directory permissions
sudo chmod 777 robo-trade-platform/uploads/profiles
sudo chmod 777 robo-trade-platform/uploads/payment_proofs
```

#### Step 4: Configure Apache
```bash
# Create virtual host
sudo nano /etc/apache2/sites-available/robo-trade.conf
```

Add this configuration:
```apache
<VirtualHost *:80>
    ServerName yourdomain.com
    ServerAlias www.yourdomain.com
    DocumentRoot /var/www/html/robo-trade-platform
    
    <Directory /var/www/html/robo-trade-platform>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    
    ErrorLog ${APACHE_LOG_DIR}/robo-trade-error.log
    CustomLog ${APACHE_LOG_DIR}/robo-trade-access.log combined
</VirtualHost>
```

Enable site and restart Apache:
```bash
sudo a2ensite robo-trade.conf
sudo systemctl restart apache2
```

#### Step 5: Update Configuration
```bash
# Edit database config
sudo nano /var/www/html/robo-trade-platform/config/database.php
```

Update with your MySQL credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'robo_user');
define('DB_PASS', 'your_strong_password');
define('DB_NAME', 'robo_trade');
```

#### Step 6: Run Installation
Navigate to: http://yourdomain.com/install.php

### Option 3: Shared Hosting (cPanel)

#### Step 1: Upload Files
1. Login to cPanel
2. Go to File Manager
3. Navigate to `public_html` directory
4. Upload `robo-trade-platform.tar.gz`
5. Extract the archive
6. Move all files from `robo-trade-platform` folder to `public_html`

#### Step 2: Create Database
1. Go to MySQL Databases in cPanel
2. Create new database: `robo_trade`
3. Create new MySQL user with strong password
4. Add user to database with ALL PRIVILEGES

#### Step 3: Configure
1. Edit `config/database.php` using File Manager editor
2. Update database credentials
3. Update `config/config.php` with your domain

#### Step 4: Set Permissions
1. Set folders to 755: `uploads`, `uploads/profiles`, `uploads/payment_proofs`
2. Set files to 644 (except PHP files which should be 644 or 600)

#### Step 5: Install
Navigate to: http://yourdomain.com/install.php

## SSL Certificate (HTTPS) Setup

### Using Let's Encrypt (Free)
```bash
# Install Certbot
sudo apt install certbot python3-certbot-apache -y

# Get certificate
sudo certbot --apache -d yourdomain.com -d www.yourdomain.com

# Auto-renewal is configured automatically
```

### Update Config for HTTPS
Edit `config/config.php`:
```php
define('SITE_URL', 'https://yourdomain.com');
ini_set('session.cookie_secure', 1); // Enable for HTTPS
```

## Production Optimization

### PHP Configuration
Edit `php.ini`:
```ini
upload_max_filesize = 10M
post_max_size = 10M
max_execution_time = 300
memory_limit = 256M
display_errors = Off
log_errors = On
error_log = /var/log/php_errors.log
```

### MySQL Optimization
```sql
# Optimize tables regularly
OPTIMIZE TABLE users, deposits, withdrawals, positions;

# Add indexes if needed
CREATE INDEX idx_user_status ON users(status);
CREATE INDEX idx_deposit_status ON deposits(status);
CREATE INDEX idx_withdrawal_status ON withdrawals(status);
```

### Apache Performance
Enable caching in `.htaccess`:
```apache
# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
</IfModule>

# Browser caching
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

## Security Hardening

### 1. File Permissions
```bash
# Set proper ownership
sudo chown -R www-data:www-data /var/www/html/robo-trade-platform

# Set directory permissions
find /var/www/html/robo-trade-platform -type d -exec chmod 755 {} \;

# Set file permissions
find /var/www/html/robo-trade-platform -type f -exec chmod 644 {} \;

# Protect config files
chmod 600 /var/www/html/robo-trade-platform/config/*.php
```

### 2. Disable Directory Listing
Add to `.htaccess`:
```apache
Options -Indexes
```

### 3. Protect Sensitive Files
Create `.htaccess` in `config/` directory:
```apache
Order deny,allow
Deny from all
```

### 4. Enable Firewall
```bash
# UFW (Ubuntu)
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 22/tcp
sudo ufw enable
```

### 5. Fail2Ban (Brute Force Protection)
```bash
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

## Backup Strategy

### Automated Daily Backup Script
Create `/usr/local/bin/backup-robo-trade.sh`:
```bash
#!/bin/bash
BACKUP_DIR="/backups/robo-trade"
DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p $BACKUP_DIR

# Database backup
mysqldump -u robo_user -p'password' robo_trade > $BACKUP_DIR/db_$DATE.sql

# Files backup
tar -czf $BACKUP_DIR/files_$DATE.tar.gz /var/www/html/robo-trade-platform/uploads

# Keep only last 7 days
find $BACKUP_DIR -type f -mtime +7 -delete

echo "Backup completed: $DATE"
```

Make executable and add to cron:
```bash
chmod +x /usr/local/bin/backup-robo-trade.sh

# Add to crontab (daily at 2 AM)
crontab -e
0 2 * * * /usr/local/bin/backup-robo-trade.sh >> /var/log/robo-trade-backup.log 2>&1
```

## Monitoring

### Log Files to Monitor
- Apache: `/var/log/apache2/robo-trade-error.log`
- PHP: `/var/log/php_errors.log`
- MySQL: `/var/log/mysql/error.log`

### Disk Space Monitoring
```bash
# Check disk usage
df -h

# Check uploads folder size
du -sh /var/www/html/robo-trade-platform/uploads
```

## Troubleshooting

### Issue: White Screen / 500 Error
```bash
# Check Apache error log
sudo tail -f /var/log/apache2/error.log

# Check PHP error log
sudo tail -f /var/log/php_errors.log

# Enable display_errors temporarily
# Edit php.ini: display_errors = On
```

### Issue: Database Connection Failed
```bash
# Test MySQL connection
mysql -u robo_user -p robo_trade

# Check MySQL service
sudo systemctl status mysql

# Restart MySQL
sudo systemctl restart mysql
```

### Issue: File Upload Not Working
```bash
# Check permissions
ls -la /var/www/html/robo-trade-platform/uploads

# Set correct permissions
sudo chmod 777 /var/www/html/robo-trade-platform/uploads/*

# Check PHP upload settings
php -i | grep upload
```

## Performance Tuning

### Enable OPcache
Edit `php.ini`:
```ini
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=4000
opcache.revalidate_freq=60
```

### MySQL Query Cache
Edit `/etc/mysql/my.cnf`:
```ini
[mysqld]
query_cache_type = 1
query_cache_size = 16M
query_cache_limit = 1M
```

## Scaling Considerations

### For High Traffic
1. **Use CDN** for static assets
2. **Enable Redis/Memcached** for session storage
3. **Database Replication** for read-heavy operations
4. **Load Balancer** for multiple web servers
5. **Separate Database Server** from web server

### Database Optimization
```sql
# Add composite indexes for common queries
CREATE INDEX idx_user_deposits ON deposits(user_id, status, created_at);
CREATE INDEX idx_user_withdrawals ON withdrawals(user_id, status, created_at);
CREATE INDEX idx_user_positions ON positions(user_id, status, created_at);
```

## Post-Deployment Checklist

- [ ] Database created and configured
- [ ] Application files uploaded and extracted
- [ ] File permissions set correctly
- [ ] Configuration files updated
- [ ] Installation completed via install.php
- [ ] install.php deleted
- [ ] Default admin password changed
- [ ] SSL certificate installed
- [ ] Firewall configured
- [ ] Backup system configured
- [ ] Error logging enabled
- [ ] Test deposit workflow
- [ ] Test withdrawal workflow
- [ ] Test trade creation
- [ ] Test user registration
- [ ] Monitor logs for errors

## Support & Maintenance

### Regular Maintenance Tasks
- **Daily**: Check error logs
- **Weekly**: Review admin logs, check disk space
- **Monthly**: Update PHP/MySQL, review security patches
- **Quarterly**: Full backup test restore

### Updating the Platform
```bash
# Backup current version
cp -r /var/www/html/robo-trade-platform /var/www/html/robo-trade-platform.backup

# Extract new version
# Restore config files
# Test thoroughly
```

---

**Need Help?**
- Check logs first
- Review README.md
- Test on local environment before production

**Version**: 1.0.0  
**Last Updated**: October 2025

