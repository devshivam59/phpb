// Dashboard JavaScript - Live Price Updates

let currentSector = 'NIFTY BANK';

// Format currency
function formatCurrency(amount) {
    return '₹' + parseFloat(amount).toFixed(2);
}

// Format change with color
function formatChange(change, pChange) {
    const sign = change >= 0 ? '+' : '';
    const className = change >= 0 ? 'price-up' : 'price-down';
    return `<span class="${className}">${sign}${change.toFixed(2)} (${sign}${pChange.toFixed(2)}%)</span>`;
}

// Update index data
function updateIndices() {
    fetch('../api/get_indices.php')
        .then(response => response.json())
        .then(data => {
            // Update Nifty
            if (data.nifty) {
                document.getElementById('nifty-price').textContent = formatCurrency(data.nifty.last);
                document.getElementById('nifty-change').innerHTML = formatChange(data.nifty.change, data.nifty.percentChange);
            }
            
            // Update Bank Nifty
            if (data.banknifty) {
                document.getElementById('banknifty-price').textContent = formatCurrency(data.banknifty.last);
                document.getElementById('banknifty-change').innerHTML = formatChange(data.banknifty.change, data.banknifty.percentChange);
            }
            
            // Update Sensex
            if (data.sensex) {
                document.getElementById('sensex-price').textContent = formatCurrency(data.sensex.last);
                document.getElementById('sensex-change').innerHTML = formatChange(data.sensex.change, data.sensex.percentChange);
            }
            
            // Update Fin Nifty
            if (data.finnifty) {
                document.getElementById('finnifty-price').textContent = formatCurrency(data.finnifty.last);
                document.getElementById('finnifty-change').innerHTML = formatChange(data.finnifty.change, data.finnifty.percentChange);
            }
        })
        .catch(error => console.error('Error fetching indices:', error));
}

// Update stocks table
function updateStocksTable(sector) {
    const tbody = document.getElementById('stocks-table');
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">Loading...</td></tr>';
    
    fetch(`../api/get_stock_data.php?sector=${encodeURIComponent(sector)}`)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No data available</td></tr>';
                return;
            }
            
            let html = '';
            data.forEach(stock => {
                const changeClass = stock.change >= 0 ? 'price-up' : 'price-down';
                const sign = stock.change >= 0 ? '+' : '';
                
                html += `
                    <tr>
                        <td><strong>${stock.symbol}</strong></td>
                        <td>${formatCurrency(stock.ltp)}</td>
                        <td class="${changeClass}">${sign}${stock.pChange.toFixed(2)}%</td>
                        <td>${formatCurrency(stock.low)}</td>
                        <td>${formatCurrency(stock.high)}</td>
                        <td>${stock.volume}</td>
                    </tr>
                `;
            });
            
            tbody.innerHTML = html;
        })
        .catch(error => {
            console.error('Error fetching stocks:', error);
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--danger-color);">Error loading data</td></tr>';
        });
}

// Sector selector change event
document.getElementById('sector-select').addEventListener('change', function() {
    currentSector = this.value;
    updateStocksTable(currentSector);
});

// Initial load
updateIndices();
updateStocksTable(currentSector);

// Auto-refresh every 5 seconds
setInterval(updateIndices, 5000);
setInterval(() => updateStocksTable(currentSector), 5000);

