# 🚀 Robo Trade Platform - Complete Setup Guide

## For Brand New Hostinger Account

This guide will help you deploy the Robo Trade Platform on a fresh Hostinger account from scratch.

---

## 📋 What You'll Get

A complete trading platform with:

✅ **Admin Panel** - Manage users, deposits, withdrawals, registrations
✅ **User Panel** - Registration, login, dashboard, funds management  
✅ **Live Market Data** - Real-time NIFTY, SENSEX, stock prices
✅ **Payment System** - QR code upload, deposit/withdrawal management
✅ **Profile Management** - Update bank details, personal info
✅ **Theme Support** - Dark/light mode toggle
✅ **Secure** - Password hashing, session management, SQL injection protection

---

## 🎯 Prerequisites

Before starting, you need:

1. ✅ **Hostinger Account** (any plan with PHP & MySQL support)
2. ✅ **Domain Name** (or use temporary Hostinger subdomain)
3. ✅ **5 minutes** of your time

That's it! Everything else is included in the package.

---

## 📦 Step 1: Upload Files (2 minutes)

### 1.1 Access File Manager

1. Login to your **Hostinger hPanel**
2. Go to **Files** → **File Manager**
3. Navigate to `/public_html/` folder

### 1.2 Upload the Package

1. Click **Upload Files**
2. Upload `ROBO-TRADE-FRESH.zip`
3. Wait for upload to complete
4. Right-click the ZIP file → **Extract**
5. You should now have a `robo-trade-platform` folder

### 1.3 Set Permissions

1. Right-click `robo-trade-platform/uploads/` → **Permissions** → Set to **755**
2. Do the same for these folders:
   - `uploads/qr_codes/` → **755**
   - `uploads/payment_proofs/` → **755**
   - `uploads/profiles/` → **755**

---

## 🗄️ Step 2: Create Database (2 minutes)

### 2.1 Create MySQL Database

1. In hPanel, go to **Databases** → **MySQL Databases**
2. Click **Create New Database**
3. Enter database name: `robo_trade` (or any name you prefer)
4. Click **Create**

### 2.2 Create Database User

1. Scroll down to **MySQL Users**
2. Click **Create New User**
3. Enter username: `robo_user` (or any name)
4. Enter a strong password (save it!)
5. Click **Create**

### 2.3 Link User to Database

1. Scroll to **Add User To Database**
2. Select your user and database
3. Grant **ALL PRIVILEGES**
4. Click **Add**

### 2.4 Note Your Credentials

Write down:
- **Database Host:** `localhost` (usually)
- **Database Name:** `robo_trade` (or what you chose)
- **Database User:** `robo_user` (or what you chose)
- **Database Password:** (the password you set)

---

## ⚙️ Step 3: Run Installer (1 minute)

### 3.1 Access Installer

1. Open your browser
2. Go to: `https://yourdomain.com/robo-trade-platform/install.php`
3. You'll see the installation wizard

### 3.2 Step 1: Database Configuration

Fill in the form with your database credentials:

- **Database Host:** `localhost`
- **Database Name:** `robo_trade`
- **Database Username:** `robo_user`
- **Database Password:** (your password)
- **Site URL:** `https://yourdomain.com/robo-trade-platform`

Click **Continue to Next Step →**

### 3.3 Step 2: Create Tables

Click **Create Database Tables**

The installer will create all 7 tables:
- admins (with default admin account)
- users
- deposits
- withdrawals
- trades
- registration_requests
- admin_settings

### 3.4 Step 3: Installation Complete!

You'll see:
```
✅ Installation Successful!

Default Admin Credentials:
Admin ID: admin001
Password: admin123
```

**IMPORTANT:** Save these credentials!

---

## 🔒 Step 4: Security (1 minute)

### 4.1 Delete Installer

**CRITICAL FOR SECURITY:**

1. Go back to File Manager
2. Navigate to `robo-trade-platform/`
3. **Delete** `install.php` file
4. This prevents unauthorized reinstallation

### 4.2 Change Admin Password

1. Go to `https://yourdomain.com/robo-trade-platform/admin/`
2. Login with `admin001` / `admin123`
3. Go to Settings or Profile
4. Change password immediately!

---

## ✅ Step 5: Test Everything (Optional)

### 5.1 Test Admin Panel

1. Go to `/admin/`
2. Login with your new password
3. Check dashboard loads
4. Check all menu items work

### 5.2 Test User Registration

1. Go to `/user/register.php`
2. Fill the registration form
3. Submit
4. Go to admin panel → Registrations
5. Approve the user
6. Test user login

### 5.3 Test Deposits/Withdrawals

1. Login as user
2. Go to Funds
3. Click "Deposit Money"
4. Check if modal opens
5. Click "Withdraw Money"
6. Check if modal opens

---

## 🎨 Step 6: Customize (Optional)

### 6.1 Enable Live Market Data

**Required for real-time stock prices:**

1. In hPanel, go to **Advanced** → **PHP Configuration**
2. Find **cURL** extension
3. Enable it
4. Save
5. Refresh your dashboard - prices should update!

### 6.2 Upload Payment QR Code

1. Login as admin
2. Go to **Settings**
3. Click **Upload QR Code**
4. Select your UPI QR code image
5. Save
6. Users will now see this QR when depositing

### 6.3 Update UPI Details

1. In Settings page
2. Update **UPI ID** (e.g., yourname@paytm)
3. Update **Account Holder Name**
4. Save

---

## 📱 Your Platform URLs

After setup, your platform will be accessible at:

- **Landing Page:** `https://yourdomain.com/robo-trade-platform/`
- **Admin Login:** `https://yourdomain.com/robo-trade-platform/admin/`
- **User Login:** `https://yourdomain.com/robo-trade-platform/user/`
- **User Registration:** `https://yourdomain.com/robo-trade-platform/user/register.php`

---

## 🎯 Default Credentials

**Admin:**
- URL: `/admin/`
- Admin ID: `admin001`
- Password: `admin123` (CHANGE THIS!)

**Database:**
- Host: `localhost`
- Name: (what you created)
- User: (what you created)
- Pass: (what you set)

---

## 🆘 Troubleshooting

### Installation fails at database connection

**Solution:**
- Verify database credentials are correct
- Check if database user has ALL PRIVILEGES
- Try using `localhost` or `127.0.0.1` as host

### Admin login shows 500 error

**Solution:**
- Check if all 7 tables were created in database
- Go to phpMyAdmin and verify tables exist
- Check error logs in hPanel

### Live prices not loading

**Solution:**
- Enable cURL extension in PHP Configuration
- Refresh the page
- Check browser console for errors

### QR code not showing in deposit

**Solution:**
- Upload QR code in admin Settings
- Check `uploads/qr_codes/` folder permissions (755)
- Verify file was uploaded successfully

### Can't upload files

**Solution:**
- Check folder permissions (should be 755)
- Increase PHP upload_max_filesize in PHP Configuration
- Try smaller file size

---

## 📞 Need Help?

### Check Error Logs

1. hPanel → **Advanced** → **Error Logs**
2. Look for PHP errors
3. Note the file and line number

### Verify Database

1. hPanel → **Databases** → **phpMyAdmin**
2. Select your database
3. Check if all 7 tables exist:
   - admins
   - users
   - deposits
   - withdrawals
   - trades
   - registration_requests
   - admin_settings

### Test in Incognito Mode

Sometimes browser cache causes issues:
1. Open incognito/private window
2. Test the platform
3. If it works, clear your browser cache

---

## ✅ Post-Setup Checklist

Before going live, verify:

- [ ] Installer deleted (`install.php`)
- [ ] Admin password changed from default
- [ ] Database credentials secured
- [ ] cURL extension enabled
- [ ] Payment QR code uploaded
- [ ] UPI details updated
- [ ] Test user registration works
- [ ] Test deposit/withdrawal works
- [ ] Test admin approval workflow
- [ ] All pages load without errors

---

## 🎉 You're Done!

Your Robo Trade Platform is now live and ready to accept users!

### Next Steps:

1. **Promote your platform** - Share the registration link
2. **Monitor registrations** - Approve users in admin panel
3. **Manage deposits** - Process deposit requests
4. **Handle withdrawals** - Approve withdrawal requests
5. **Track trades** - Monitor user trading activity

---

## 🔐 Security Best Practices

1. ✅ **Strong passwords** - Use complex admin password
2. ✅ **Regular backups** - Backup database weekly
3. ✅ **Update regularly** - Keep platform updated
4. ✅ **Monitor logs** - Check error logs regularly
5. ✅ **SSL certificate** - Use HTTPS (Hostinger provides free SSL)

---

## 📊 Platform Features

### For Admin:
- Dashboard with statistics
- User management
- Registration approval system
- Deposit management
- Withdrawal management
- Trade monitoring
- Payment settings (QR code upload)

### For Users:
- Easy registration
- Secure login
- Live market data (NIFTY, SENSEX, stocks)
- Deposit funds with QR code
- Withdraw funds
- Profile management
- Bank details update
- Dark/light theme toggle

---

**Congratulations! Your trading platform is ready! 🚀💰**

For any issues, check the troubleshooting section or review the error logs in your hosting panel.

Happy trading!
