<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robo Trade Platform - Installation</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
            padding: 40px;
        }
        h1 {
            color: #667eea;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 16px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
            font-size: 14px;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }
        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .alert-info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .success-icon {
            font-size: 60px;
            text-align: center;
            margin-bottom: 20px;
        }
        .btn-secondary {
            background: #6c757d;
            margin-top: 10px;
        }
        .help-text {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .step-indicator {
            text-align: center;
            margin-bottom: 30px;
            color: #667eea;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        $step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
        $success = false;
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 1) {
            // Step 1: Database Configuration
            $db_host = trim($_POST['db_host']);
            $db_user = trim($_POST['db_user']);
            $db_pass = $_POST['db_pass'];
            $db_name = trim($_POST['db_name']);
            $site_url = trim($_POST['site_url']);

            // Test database connection
            $conn = @new mysqli($db_host, $db_user, $db_pass, $db_name);
            
            if ($conn->connect_error) {
                $error = "Database connection failed: " . $conn->connect_error;
            } else {
                // Create config file
                $config_content = "<?php\n";
                $config_content .= "// Application Configuration\n\n";
                $config_content .= "// Database Configuration\n";
                $config_content .= "define('DB_HOST', '$db_host');\n";
                $config_content .= "define('DB_USER', '$db_user');\n";
                $config_content .= "define('DB_PASS', '$db_pass');\n";
                $config_content .= "define('DB_NAME', '$db_name');\n\n";
                $config_content .= "// Session Configuration\n";
                $config_content .= "ini_set('session.gc_maxlifetime', 86400);\n";
                $config_content .= "ini_set('session.cookie_lifetime', 86400);\n";
                $config_content .= "session_set_cookie_params(86400);\n\n";
                $config_content .= "if (session_status() === PHP_SESSION_NONE) {\n";
                $config_content .= "    session_start();\n";
                $config_content .= "}\n\n";
                $config_content .= "if (!isset(\$_SESSION['last_regeneration'])) {\n";
                $config_content .= "    \$_SESSION['last_regeneration'] = time();\n";
                $config_content .= "} elseif (time() - \$_SESSION['last_regeneration'] > 1800) {\n";
                $config_content .= "    session_regenerate_id(true);\n";
                $config_content .= "    \$_SESSION['last_regeneration'] = time();\n";
                $config_content .= "}\n\n";
                $config_content .= "// Application Settings\n";
                $config_content .= "define('APP_NAME', 'Robo Trade Platform');\n";
                $config_content .= "define('SITE_NAME', 'Robo Trade Platform');\n";
                $config_content .= "define('APP_VERSION', '2.0');\n";
                $config_content .= "define('SITE_URL', '$site_url');\n\n";
                $config_content .= "// UPI Payment Details\n";
                $config_content .= "define('UPI_ID', 'payment@robotrade');\n";
                $config_content .= "define('UPI_NAME', 'Robo Trade Platform');\n\n";
                $config_content .= "// File Upload Settings\n";
                $config_content .= "define('MAX_UPLOAD_SIZE', 5242880);\n";
                $config_content .= "define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/gif']);\n\n";
                $config_content .= "// Timezone\n";
                $config_content .= "date_default_timezone_set('Asia/Kolkata');\n\n";
                $config_content .= "// Error Reporting\n";
                $config_content .= "error_reporting(E_ALL);\n";
                $config_content .= "ini_set('display_errors', 0);\n";
                $config_content .= "ini_set('log_errors', 1);\n";
                $config_content .= "ini_set('error_log', __DIR__ . '/../logs/error.log');\n";
                $config_content .= "?>\n";

                if (file_put_contents(__DIR__ . '/config/config.php', $config_content)) {
                    header('Location: install.php?step=2');
                    exit;
                } else {
                    $error = "Failed to create config file. Please check folder permissions.";
                }
                
                $conn->close();
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && $step == 2) {
            // Step 2: Create Database Tables
            require_once __DIR__ . '/config/config.php';
            
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            
            if ($conn->connect_error) {
                $error = "Database connection failed: " . $conn->connect_error;
            } else {
                // Create tables
                $sql = file_get_contents(__DIR__ . '/database_schema.sql');
                
                if ($conn->multi_query($sql)) {
                    do {
                        if ($result = $conn->store_result()) {
                            $result->free();
                        }
                    } while ($conn->more_results() && $conn->next_result());
                    
                    header('Location: install.php?step=3');
                    exit;
                } else {
                    $error = "Failed to create tables: " . $conn->error;
                }
                
                $conn->close();
            }
        }

        // Display appropriate step
        if ($step == 1):
        ?>
            <div class="step-indicator">Step 1 of 3: Database Configuration</div>
            <h1>🚀 Robo Trade Platform</h1>
            <p class="subtitle">Welcome! Let's set up your trading platform.</p>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <div class="alert alert-info">
                <strong>Before you begin:</strong><br>
                1. Create a MySQL database in your hosting panel<br>
                2. Create a database user with all privileges<br>
                3. Note down the database credentials
            </div>

            <form method="POST">
                <div class="form-group">
                    <label>Database Host</label>
                    <input type="text" name="db_host" value="localhost" required>
                    <div class="help-text">Usually "localhost" for most hosting providers</div>
                </div>

                <div class="form-group">
                    <label>Database Name</label>
                    <input type="text" name="db_name" placeholder="robo_trade" required>
                    <div class="help-text">The name of the database you created</div>
                </div>

                <div class="form-group">
                    <label>Database Username</label>
                    <input type="text" name="db_user" placeholder="root" required>
                </div>

                <div class="form-group">
                    <label>Database Password</label>
                    <input type="password" name="db_pass" placeholder="Enter database password">
                </div>

                <div class="form-group">
                    <label>Site URL</label>
                    <input type="text" name="site_url" placeholder="https://yourdomain.com" required>
                    <div class="help-text">Your website URL (without trailing slash)</div>
                </div>

                <button type="submit" class="btn">Continue to Next Step →</button>
            </form>

        <?php elseif ($step == 2): ?>
            <div class="step-indicator">Step 2 of 3: Create Database Tables</div>
            <h1>📊 Database Setup</h1>
            <p class="subtitle">Creating database tables and default admin account...</p>

            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <div class="alert alert-info">
                This will create all necessary tables:<br>
                • Admins (with default admin account)<br>
                • Users<br>
                • Deposits & Withdrawals<br>
                • Trades<br>
                • Registration Requests<br>
                • Admin Settings
            </div>

            <form method="POST">
                <button type="submit" class="btn">Create Database Tables</button>
            </form>

        <?php elseif ($step == 3): ?>
            <div class="success-icon">✅</div>
            <h1 style="text-align: center;">Installation Complete!</h1>
            <p class="subtitle" style="text-align: center;">Your Robo Trade Platform is ready to use.</p>

            <div class="alert alert-success">
                <strong>✅ Installation Successful!</strong><br><br>
                <strong>Default Admin Credentials:</strong><br>
                Admin ID: <strong>admin001</strong><br>
                Password: <strong>admin123</strong><br><br>
                ⚠️ <strong>IMPORTANT:</strong> Change this password immediately after login!
            </div>

            <div class="alert alert-info">
                <strong>Next Steps:</strong><br>
                1. Delete the install.php file for security<br>
                2. Login to admin panel and change password<br>
                3. Enable PHP cURL extension for live market data<br>
                4. Upload your payment QR code in Settings<br>
                5. Start accepting user registrations!
            </div>

            <a href="admin/" class="btn" style="display: block; text-align: center; text-decoration: none;">Go to Admin Panel →</a>
            <a href="user/" class="btn btn-secondary" style="display: block; text-align: center; text-decoration: none;">Go to User Panel →</a>

        <?php endif; ?>
    </div>
</body>
</html>
