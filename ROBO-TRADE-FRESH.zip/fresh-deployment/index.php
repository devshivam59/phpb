<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Robo Trade Platform</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 50px;
            max-width: 600px;
            width: 100%;
            text-align: center;
        }
        h1 {
            color: #333;
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .subtitle {
            color: #666;
            font-size: 1.1em;
            margin-bottom: 40px;
        }
        .buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn {
            display: inline-block;
            padding: 15px 40px;
            font-size: 1.1em;
            font-weight: 600;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            min-width: 200px;
        }
        .btn-admin {
            background: #2563eb;
            color: white;
        }
        .btn-admin:hover {
            background: #1d4ed8;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(37, 99, 235, 0.3);
        }
        .btn-user {
            background: #10b981;
            color: white;
        }
        .btn-user:hover {
            background: #059669;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(16, 185, 129, 0.3);
        }
        .features {
            margin-top: 40px;
            padding-top: 30px;
            border-top: 1px solid #e5e7eb;
        }
        .features h3 {
            color: #333;
            margin-bottom: 20px;
        }
        .feature-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            text-align: left;
        }
        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #666;
        }
        .feature-item::before {
            content: "✓";
            color: #10b981;
            font-weight: bold;
            font-size: 1.2em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Robo Trade Platform</h1>
        <p class="subtitle">Your Complete Trading Solution</p>
        
        <div class="buttons">
            <a href="admin/" class="btn btn-admin">Admin Panel</a>
            <a href="user/" class="btn btn-user">User Panel</a>
        </div>
        
        <div class="features">
            <h3>Platform Features</h3>
            <div class="feature-list">
                <div class="feature-item">Live Market Data</div>
                <div class="feature-item">Real-time Trading</div>
                <div class="feature-item">Deposit & Withdrawal</div>
                <div class="feature-item">User Management</div>
                <div class="feature-item">Trade Management</div>
                <div class="feature-item">Secure Transactions</div>
            </div>
        </div>
    </div>
</body>
</html>
