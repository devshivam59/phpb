<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || isAdmin()) redirect('index.php');
$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $conn = getDBConnection();
    
    
    
    if ($_POST['action'] === 'update_bank') {
        $bank_name = sanitize($_POST['bank_name']);
        $account_number = sanitize($_POST['account_number']);
        $ifsc_code = strtoupper(sanitize($_POST['ifsc_code']));
        $account_holder = sanitize($_POST['account_holder']);
        
        $stmt = $conn->prepare("UPDATE users SET bank_name=?, account_number=?, ifsc_code=? WHERE id=?");
        $stmt->bind_param("sssi", $bank_name, $account_number, $ifsc_code, $user_id);
        if ($stmt->execute()) {
            $success = 'Bank details updated successfully';
            $user = getUserData($user_id);
        } else {
            $error = 'Failed to update bank details';
        }
        $stmt->close();
    }
    
    if ($_POST['action'] === 'toggle_theme') {
        $current_theme = $user['theme_preference'] ?? 'dark';
        $new_theme = ($current_theme === 'dark') ? 'light' : 'dark';
        
        $stmt = $conn->prepare("UPDATE users SET theme_preference=? WHERE id=?");
        $stmt->bind_param("si", $new_theme, $user_id);
        if ($stmt->execute()) {
            $user = getUserData($user_id);
            header('Location: profile.php');
            exit;
        }
        $stmt->close();
    }
    
    if ($_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $error = 'New passwords do not match';
        } elseif (strlen($new_password) < 6) {
            $error = 'Password must be at least 6 characters';
        } else {
            $stmt = $conn->prepare("SELECT password FROM users WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            
            if (password_verify($current_password, $result['password'])) {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param("si", $hashed, $user_id);
                if ($stmt->execute()) {
                    $success = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
            } else {
                $error = 'Current password is incorrect';
            }
            $stmt->close();
        }
    }
    
    $conn->close();
}

$profile_photo_url = $user['profile_photo'] ? '../uploads/profiles/' . $user['profile_photo'] : null;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Profile</title>
    <link rel="stylesheet" href="../assets/css/mobile-style.css">
    <style>
        <?php if (($user['theme_preference'] ?? 'dark') === 'light'): ?>
        :root {
            --dark-bg: #f1f5f9;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --text: #0f172a;
            --text-secondary: #64748b;
        }
        body {
            background: var(--dark-bg);
            color: var(--text);
        }
        .bottom-nav {
            background: #ffffff;
        }
        <?php endif; ?>
        
        .profile-photo-upload {
            position: relative;
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            cursor: pointer;
        }
        .profile-photo-upload img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary);
        }
        .profile-photo-upload .upload-overlay {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 32px;
            height: 32px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.9rem;
            border: 2px solid var(--dark-bg);
        }
        .profile-photo-upload input[type="file"] {
            display: none;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="header">
            <div class="header-content">
                <div style="font-size: 1.2rem; font-weight: 600;"><i class="fas fa-user"></i> Profile</div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; opacity: 0.9;">Balance</div>
                    <div class="balance-amount"><?php echo formatCurrency($balance); ?></div>
                </div>
            </div>
        </div>
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
            <?php endif; ?>

            <!-- User Info Card -->
            <div class="card">
                <div style="text-align: center; margin-bottom: 20px;">
                    <!-- Profile Photo (Read-Only) -->
                    <div style="width: 100px; height: 100px; margin: 0 auto;">
                        <?php if ($profile_photo_url): ?>
                            <img src="<?php echo $profile_photo_url; ?>" alt="Profile Photo" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover; border: 3px solid var(--primary);">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; border-radius: 50%; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; color: white; font-size: 2.5rem;">
                                <i class="fas fa-user"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div style="font-size: 1.3rem; font-weight: 600;"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                    <div style="color: var(--text-secondary); margin-top: 5px;">
                        <i class="fas fa-id-badge"></i> <?php echo $user['user_id']; ?>
                    </div>
                    <div style="color: var(--text-secondary); margin-top: 5px; font-size: 0.85rem;">
                        <i class="fas fa-calendar-alt"></i> Member since <?php echo date('M Y', strtotime($user['created_at'])); ?>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr; gap: 12px;">
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-envelope"></i> Email Address
                        </div>
                        <div style="font-weight: 600; word-break: break-all;"><?php echo $user['email']; ?></div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-phone"></i> Phone Number
                        </div>
                        <div style="font-weight: 600;"><?php echo $user['phone'] ?: 'Not set'; ?></div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-wallet"></i> Account Balance
                        </div>
                        <div style="font-weight: 600; font-size: 1.2rem; color: var(--success);"><?php echo formatCurrency($balance); ?></div>
                    </div>
                </div>
            </div>

            <!-- Theme Toggle -->
            <div class="card">
                <div class="card-title"><i class="fas fa-palette"></i> Appearance</div>
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="action" value="toggle_theme">
                    <button type="submit" class="btn btn-primary" style="display: flex; align-items: center; justify-content: center; gap: 10px;">
                        <i class="fas fa-<?php echo ($user['theme_preference'] ?? 'dark') === 'dark' ? 'sun' : 'moon'; ?>"></i>
                        <span><?php echo ($user['theme_preference'] ?? 'dark') === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'; ?></span>
                    </button>
                </form>
            </div>

            <!-- Personal Information (Read-Only) -->
            <div class="card">
                <div class="card-title"><i class="fas fa-id-card"></i> Personal Information</div>
                <div style="display: grid; grid-template-columns: 1fr; gap: 12px;">
                    <?php if ($user['dob']): ?>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-birthday-cake"></i> Date of Birth
                        </div>
                        <div style="font-weight: 600;"><?php echo date('d M Y', strtotime($user['dob'])); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($user['address']): ?>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-map-marker-alt"></i> Address
                        </div>
                        <div style="font-weight: 600;"><?php echo $user['address']; ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($user['pan_card']): ?>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-id-card"></i> PAN Card
                        </div>
                        <div style="font-weight: 600;"><?php echo $user['pan_card']; ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if ($user['aadhaar_card']): ?>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-id-card-alt"></i> Aadhaar Card
                        </div>
                        <div style="font-weight: 600;"><?php echo $user['aadhaar_card']; ?></div>
                    </div>
                    <?php endif; ?>
                </div>
                <div style="margin-top: 15px; padding: 12px; background: rgba(59,130,246,0.1); border-radius: 10px; font-size: 0.85rem; color: var(--text-secondary);">
                    <i class="fas fa-info-circle"></i> Contact admin to update personal information
                </div>
            </div>

            <!-- Bank Details -->
            <div class="card">
                <div class="card-title"><i class="fas fa-university"></i> Bank Details</div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_bank">
                    <div class="form-group">
                        <label class="form-label">Bank Name *</label>
                        <input type="text" name="bank_name" class="form-control" value="<?php echo $user['bank_name']; ?>" placeholder="e.g., HDFC Bank" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Account Number *</label>
                        <input type="text" name="account_number" class="form-control" value="<?php echo $user['account_number']; ?>" placeholder="Enter account number" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">IFSC Code *</label>
                        <input type="text" name="ifsc_code" class="form-control" value="<?php echo $user['ifsc_code']; ?>" placeholder="e.g., HDFC0001234" maxlength="11" style="text-transform: uppercase;" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Bank Details</button>
                </form>
            </div>

            <!-- Change Password -->
            <div class="card">
                <div class="card-title"><i class="fas fa-lock"></i> Change Password</div>
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <div class="form-group">
                        <label class="form-label">Current Password *</label>
                        <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password *</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Enter new password (min 6 chars)" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password *</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter new password" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-key"></i> Change Password</button>
                </form>
            </div>

            <!-- Logout -->
            <div class="card">
                <a href="logout.php" style="display: block; text-align: center; padding: 14px; background: rgba(239,68,68,0.1); border-radius: 12px; color: var(--danger); text-decoration: none; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
        <div class="bottom-nav">
            <a href="dashboard.php" class="nav-item"><div class="nav-icon"><i class="fas fa-home"></i></div><div class="nav-label">Home</div></a>
            <a href="positions.php" class="nav-item"><div class="nav-icon"><i class="fas fa-chart-bar"></i></div><div class="nav-label">Positions</div></a>
            <a href="funds.php" class="nav-item"><div class="nav-icon"><i class="fas fa-wallet"></i></div><div class="nav-label">Funds</div></a>
            <a href="profile.php" class="nav-item active"><div class="nav-icon"><i class="fas fa-user"></i></div><div class="nav-label">Profile</div></a>
        </div>
    </div>
</body>
</html>
