<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || isAdmin()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);
$notifications_count = getUnreadNotificationsCount($user_id);

// Get deposits
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT * FROM deposits WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$deposits = [];
while ($row = $result->fetch_assoc()) {
    $deposits[] = $row;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit History - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Deposit History</h1>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Deposits</h2>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Admin Note</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($deposits)): ?>
                                <tr>
                                    <td colspan="7" style="text-align: center;">No deposits found</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($deposits as $index => $deposit): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><strong><?php echo formatCurrency($deposit['amount']); ?></strong></td>
                                        <td><?php echo $deposit['payment_method']; ?></td>
                                        <td><?php echo $deposit['transaction_id']; ?></td>
                                        <td><?php echo formatDateTime($deposit['created_at']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $deposit['status']; ?>">
                                                <?php echo ucfirst($deposit['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($deposit['admin_note']): ?>
                                                <small style="color: var(--text-secondary);"><?php echo $deposit['admin_note']; ?></small>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

