<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || isAdmin()) redirect('index.php');
$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $conn = getDBConnection();
    
    if ($_POST['action'] === 'upload_photo') {
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $filename = $_FILES['profile_photo']['name'];
            $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($filetype, $allowed)) {
                if ($_FILES['profile_photo']['size'] < 5000000) { // 5MB max
                    $new_filename = 'user_' . $user_id . '_' . time() . '.' . $filetype;
                    $upload_path = __DIR__ . '/../uploads/profiles/' . $new_filename;
                    
                    if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_path)) {
                        // Delete old photo if exists
                        if ($user['profile_image'] && file_exists(__DIR__ . '/../uploads/profiles/' . $user['profile_image'])) {
                            unlink(__DIR__ . '/../uploads/profiles/' . $user['profile_image']);
                        }
                        
                        $stmt = $conn->prepare("UPDATE users SET profile_image=? WHERE id=?");
                        $stmt->bind_param("si", $new_filename, $user_id);
                        if ($stmt->execute()) {
                            $success = 'Profile photo updated successfully';
                            $user = getUserData($user_id);
                        }
                        $stmt->close();
                    } else {
                        $error = 'Failed to upload photo';
                    }
                } else {
                    $error = 'File size must be less than 5MB';
                }
            } else {
                $error = 'Only JPG, JPEG, PNG & GIF files are allowed';
            }
        }
    }
    
    if ($_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $error = 'New passwords do not match';
        } elseif (strlen($new_password) < 6) {
            $error = 'Password must be at least 6 characters';
        } else {
            $stmt = $conn->prepare("SELECT password FROM users WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            
            if (password_verify($current_password, $result['password'])) {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param("si", $hashed, $user_id);
                if ($stmt->execute()) {
                    $success = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
                $stmt->close();
            } else {
                $error = 'Current password is incorrect';
            }
        }
    }
    
    if ($_POST['action'] === 'toggle_theme') {
        $current_theme = $user['theme_preference'] ?? 'dark';
        $new_theme = ($current_theme === 'dark') ? 'light' : 'dark';
        
        $stmt = $conn->prepare("UPDATE users SET theme_preference=? WHERE id=?");
        $stmt->bind_param("si", $new_theme, $user_id);
        if ($stmt->execute()) {
            $user = getUserData($user_id);
            header('Location: profile_updated.php');
            exit;
        }
        $stmt->close();
    }
    
    $conn->close();
}

$theme_mode = $user['theme_preference'] ?? 'dark';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $theme_mode; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        :root[data-theme="light"] {
            --bg-primary: #f5f7fa;
            --bg-secondary: #ffffff;
            --text-primary: #1a202c;
            --text-secondary: #4a5568;
            --border-color: #e2e8f0;
            --card-bg: #ffffff;
            --input-bg: #f7fafc;
        }
        
        :root[data-theme="dark"] {
            --bg-primary: #1a202c;
            --bg-secondary: #2d3748;
            --text-primary: #f7fafc;
            --text-secondary: #cbd5e0;
            --border-color: #4a5568;
            --card-bg: #2d3748;
            --input-bg: #1a202c;
        }
        
        body {
            background: var(--bg-primary);
            color: var(--text-primary);
        }
        
        .profile-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .profile-header {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        
        .profile-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .profile-avatar {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            position: relative;
        }
        
        .profile-avatar img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .theme-toggle {
            background: var(--card-bg);
            border: 2px solid var(--border-color);
            border-radius: 50px;
            padding: 10px 20px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
        }
        
        .theme-toggle:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .section-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-primary);
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .info-item {
            padding: 15px;
            background: var(--input-bg);
            border-radius: 10px;
            border: 1px solid var(--border-color);
        }
        
        .info-label {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .info-value {
            font-size: 1rem;
            color: var(--text-primary);
            font-weight: 600;
        }
        
        .readonly-badge {
            display: inline-block;
            background: #e53e3e;
            color: white;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 0.7rem;
            margin-left: 8px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-primary);
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: var(--input-bg);
            color: var(--text-primary);
            font-size: 1rem;
        }
        
        .btn {
            padding: 12px 24px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: #e53e3e;
            color: white;
        }
        
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .alert-error {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .quick-links {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        
        .quick-link {
            padding: 10px 20px;
            background: var(--input-bg);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            text-decoration: none;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        
        .quick-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <div class="profile-header">
            <div class="profile-info">
                <div class="profile-avatar">
                    <?php if ($user['profile_image']): ?>
                        <img src="../uploads/profiles/<?php echo $user['profile_image']; ?>" alt="Profile">
                    <?php else: ?>
                        <i class="fas fa-user"></i>
                    <?php endif; ?>
                </div>
                <div>
                    <h1><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h1>
                    <p style="color: var(--text-secondary);">User ID: <?php echo $user['user_id']; ?></p>
                    <p style="color: #48bb78; font-weight: 600;">Balance: ₹<?php echo number_format($balance, 2); ?></p>
                </div>
            </div>
            <form method="POST" style="margin: 0;">
                <input type="hidden" name="action" value="toggle_theme">
                <button type="submit" class="theme-toggle">
                    <i class="fas fa-<?php echo $theme_mode === 'dark' ? 'sun' : 'moon'; ?>"></i>
                    <span><?php echo $theme_mode === 'dark' ? 'Light Mode' : 'Dark Mode'; ?></span>
                </button>
            </form>
        </div>
        
        <!-- Personal Information (Read-Only) -->
        <div class="section-card">
            <h2 class="section-title">
                <i class="fas fa-user-circle"></i>
                Personal Information
                <span class="readonly-badge">READ ONLY</span>
            </h2>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Full Name</div>
                    <div class="info-value"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Email Address</div>
                    <div class="info-value"><?php echo $user['email'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Phone Number</div>
                    <div class="info-value"><?php echo $user['phone'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Date of Birth</div>
                    <div class="info-value"><?php echo $user['dob'] ? date('d M Y', strtotime($user['dob'])) : 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Address</div>
                    <div class="info-value"><?php echo $user['address'] ?: 'Not provided'; ?></div>
                </div>
            </div>
        </div>
        
        <!-- KYC Information (Read-Only) -->
        <div class="section-card">
            <h2 class="section-title">
                <i class="fas fa-id-card"></i>
                KYC Information
                <span class="readonly-badge">READ ONLY</span>
            </h2>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">PAN Card</div>
                    <div class="info-value"><?php echo $user['pan_card'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Aadhaar Card</div>
                    <div class="info-value"><?php echo $user['aadhaar_card'] ?: 'Not provided'; ?></div>
                </div>
            </div>
            <p style="color: var(--text-secondary); margin-top: 15px; font-size: 0.9rem;">
                <i class="fas fa-info-circle"></i> Contact admin to update your personal and KYC information.
            </p>
        </div>
        
        <!-- Bank Details (Read-Only) -->
        <div class="section-card">
            <h2 class="section-title">
                <i class="fas fa-university"></i>
                Bank Details
                <span class="readonly-badge">READ ONLY</span>
            </h2>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Account Holder Name</div>
                    <div class="info-value"><?php echo $user['account_holder_name'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Bank Name</div>
                    <div class="info-value"><?php echo $user['bank_name'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Account Number</div>
                    <div class="info-value"><?php echo $user['account_number'] ?: 'Not provided'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">IFSC Code</div>
                    <div class="info-value"><?php echo $user['ifsc_code'] ?: 'Not provided'; ?></div>
                </div>
            </div>
            <p style="color: var(--text-secondary); margin-top: 15px; font-size: 0.9rem;">
                <i class="fas fa-info-circle"></i> Contact admin to update your bank details.
            </p>
        </div>
        
        <!-- Change Password -->
        <div class="section-card">
            <h2 class="section-title">
                <i class="fas fa-lock"></i>
                Change Password
            </h2>
            <form method="POST">
                <input type="hidden" name="action" value="change_password">
                <div class="form-group">
                    <label class="form-label">Current Password *</label>
                    <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                </div>
                <div class="form-group">
                    <label class="form-label">New Password *</label>
                    <input type="password" name="new_password" class="form-control" placeholder="Enter new password (min 6 chars)" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Confirm New Password *</label>
                    <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter new password" required>
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-key"></i> Change Password
                </button>
            </form>
        </div>
        
        <!-- Quick Links -->
        <div class="section-card">
            <h2 class="section-title">
                <i class="fas fa-link"></i>
                Quick Links
            </h2>
            <div class="quick-links">
                <a href="dashboard.php" class="quick-link">
                    <i class="fas fa-home"></i> Dashboard
                </a>
                <a href="positions.php" class="quick-link">
                    <i class="fas fa-chart-line"></i> Positions
                </a>
                <a href="funds.php" class="quick-link">
                    <i class="fas fa-wallet"></i> Funds
                </a>
                <a href="themes.php" class="quick-link">
                    <i class="fas fa-palette"></i> Change Theme
                </a>
                <a href="logout.php" class="quick-link" style="color: #e53e3e;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
    </div>
</body>
</html>
