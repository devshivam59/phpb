<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || isAdmin()) redirect('index.php');
$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $conn = getDBConnection();
    
    if ($_POST['action'] === 'upload_photo') {
        if (isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $filename = $_FILES['profile_photo']['name'];
            $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($filetype, $allowed)) {
                if ($_FILES['profile_photo']['size'] < 5000000) { // 5MB max
                    $new_filename = 'user_' . $user_id . '_' . time() . '.' . $filetype;
                    $upload_path = __DIR__ . '/../uploads/profiles/' . $new_filename;
                    
                    if (move_uploaded_file($_FILES['profile_photo']['tmp_name'], $upload_path)) {
                        // Delete old photo if exists
                        if ($user['profile_photo'] && file_exists(__DIR__ . '/../uploads/profiles/' . $user['profile_photo'])) {
                            unlink(__DIR__ . '/../uploads/profiles/' . $user['profile_photo']);
                        }
                        
                        $stmt = $conn->prepare("UPDATE users SET profile_photo=? WHERE id=?");
                        $stmt->bind_param("si", $new_filename, $user_id);
                        if ($stmt->execute()) {
                            $success = 'Profile photo updated successfully';
                            $user = getUserData($user_id);
                        }
                        $stmt->close();
                    } else {
                        $error = 'Failed to upload photo';
                    }
                } else {
                    $error = 'File size must be less than 5MB';
                }
            } else {
                $error = 'Only JPG, JPEG, PNG & GIF files are allowed';
            }
        }
    }
    
    if ($_POST['action'] === 'update_profile') {
        $phone = sanitize($_POST['phone']);
        $stmt = $conn->prepare("UPDATE users SET phone=? WHERE id=?");
        $stmt->bind_param("si", $phone, $user_id);
        if ($stmt->execute()) {
            $success = 'Profile updated successfully';
            $user = getUserData($user_id);
        } else {
            $error = 'Failed to update profile';
        }
        $stmt->close();
    }
    
    if ($_POST['action'] === 'update_bank') {
        $bank_name = sanitize($_POST['bank_name']);
        $account_number = sanitize($_POST['account_number']);
        $ifsc_code = strtoupper(sanitize($_POST['ifsc_code']));
        $account_holder = sanitize($_POST['account_holder']);
        
        $stmt = $conn->prepare("UPDATE users SET bank_name=?, account_number=?, ifsc_code=?, account_holder_name=? WHERE id=?");
        $stmt->bind_param("ssssi", $bank_name, $account_number, $ifsc_code, $account_holder, $user_id);
        if ($stmt->execute()) {
            $success = 'Bank details updated successfully';
            $user = getUserData($user_id);
        } else {
            $error = 'Failed to update bank details';
        }
        $stmt->close();
    }
    
    if ($_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $error = 'New passwords do not match';
        } elseif (strlen($new_password) < 6) {
            $error = 'Password must be at least 6 characters';
        } else {
            $stmt = $conn->prepare("SELECT password FROM users WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            
            if (password_verify($current_password, $result['password'])) {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param("si", $hashed, $user_id);
                if ($stmt->execute()) {
                    $success = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
            } else {
                $error = 'Current password is incorrect';
            }
            $stmt->close();
        }
    }
    
    $conn->close();
}

$profile_photo_url = $user['profile_photo'] ? '../uploads/profiles/' . $user['profile_photo'] : null;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Profile</title>
    <link rel="stylesheet" href="../assets/css/mobile-style.css">
    <style>
        .profile-photo-upload {
            position: relative;
            width: 100px;
            height: 100px;
            margin: 0 auto 20px;
            cursor: pointer;
        }
        .profile-photo-upload img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--primary);
        }
        .profile-photo-upload .upload-overlay {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 32px;
            height: 32px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.9rem;
            border: 2px solid var(--dark-bg);
        }
        .profile-photo-upload input[type="file"] {
            display: none;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="header">
            <div class="header-content">
                <div style="font-size: 1.2rem; font-weight: 600;"><i class="fas fa-user"></i> Profile</div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; opacity: 0.9;">Balance</div>
                    <div class="balance-amount"><?php echo formatCurrency($balance); ?></div>
                </div>
            </div>
        </div>
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
            <?php endif; ?>

            <!-- User Info Card -->
            <div class="card">
                <div style="text-align: center; margin-bottom: 20px;">
                    <!-- Profile Photo Upload -->
                    <form method="POST" enctype="multipart/form-data" id="photoForm">
                        <input type="hidden" name="action" value="upload_photo">
                        <div class="profile-photo-upload" onclick="document.getElementById('photoInput').click()">
                            <?php if ($profile_photo_url): ?>
                                <img src="<?php echo $profile_photo_url; ?>" alt="Profile Photo">
                            <?php else: ?>
                                <div class="profile-avatar">
                                    <i class="fas fa-user"></i>
                                </div>
                            <?php endif; ?>
                            <div class="upload-overlay">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>
                        <input type="file" id="photoInput" name="profile_photo" accept="image/*" onchange="document.getElementById('photoForm').submit()">
                    </form>
                    
                    <div style="font-size: 1.3rem; font-weight: 600;"><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></div>
                    <div style="color: var(--text-secondary); margin-top: 5px;">
                        <i class="fas fa-id-badge"></i> <?php echo $user['user_id']; ?>
                    </div>
                    <div style="color: var(--text-secondary); margin-top: 5px; font-size: 0.85rem;">
                        <i class="fas fa-calendar-alt"></i> Member since <?php echo date('M Y', strtotime($user['created_at'])); ?>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr; gap: 12px;">
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-envelope"></i> Email Address
                        </div>
                        <div style="font-weight: 600; word-break: break-all;"><?php echo $user['email']; ?></div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-phone"></i> Phone Number
                        </div>
                        <div style="font-weight: 600;"><?php echo $user['phone'] ?: 'Not set'; ?></div>
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 15px; border-radius: 12px;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">
                            <i class="fas fa-wallet"></i> Account Balance
                        </div>
                        <div style="font-weight: 600; font-size: 1.2rem; color: var(--success);"><?php echo formatCurrency($balance); ?></div>
                    </div>
                </div>
            </div>

            <!-- Update Phone -->
            <div class="card">
                <div class="card-title"><i class="fas fa-edit"></i> Update Contact</div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-phone"></i> Phone Number</label>
                        <input type="tel" name="phone" class="form-control" value="<?php echo $user['phone']; ?>" placeholder="Enter phone number" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Contact</button>
                </form>
            </div>

            <!-- Bank Details -->
            <div class="card">
                <div class="card-title"><i class="fas fa-university"></i> Bank Details</div>
                <form method="POST">
                    <input type="hidden" name="action" value="update_bank">
                    <div class="form-group">
                        <label class="form-label">Account Holder Name *</label>
                        <input type="text" name="account_holder" class="form-control" value="<?php echo $user['account_holder_name']; ?>" placeholder="Full name as per bank" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Bank Name *</label>
                        <input type="text" name="bank_name" class="form-control" value="<?php echo $user['bank_name']; ?>" placeholder="e.g., HDFC Bank" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Account Number *</label>
                        <input type="text" name="account_number" class="form-control" value="<?php echo $user['account_number']; ?>" placeholder="Enter account number" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">IFSC Code *</label>
                        <input type="text" name="ifsc_code" class="form-control" value="<?php echo $user['ifsc_code']; ?>" placeholder="e.g., HDFC0001234" maxlength="11" style="text-transform: uppercase;" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Bank Details</button>
                </form>
            </div>

            <!-- Change Password -->
            <div class="card">
                <div class="card-title"><i class="fas fa-lock"></i> Change Password</div>
                <form method="POST">
                    <input type="hidden" name="action" value="change_password">
                    <div class="form-group">
                        <label class="form-label">Current Password *</label>
                        <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Password *</label>
                        <input type="password" name="new_password" class="form-control" placeholder="Enter new password (min 6 chars)" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm New Password *</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter new password" required>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-key"></i> Change Password</button>
                </form>
            </div>

            <!-- Logout -->
            <div class="card">
                <a href="logout.php" style="display: block; text-align: center; padding: 14px; background: rgba(239,68,68,0.1); border-radius: 12px; color: var(--danger); text-decoration: none; font-weight: 600;">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </div>
        <div class="bottom-nav">
            <a href="dashboard.php" class="nav-item"><div class="nav-icon"><i class="fas fa-home"></i></div><div class="nav-label">Home</div></a>
            <a href="positions.php" class="nav-item"><div class="nav-icon"><i class="fas fa-chart-bar"></i></div><div class="nav-label">Positions</div></a>
            <a href="funds.php" class="nav-item"><div class="nav-icon"><i class="fas fa-wallet"></i></div><div class="nav-label">Funds</div></a>
            <a href="profile.php" class="nav-item active"><div class="nav-icon"><i class="fas fa-user"></i></div><div class="nav-label">Profile</div></a>
        </div>
    </div>
</body>
</html>
