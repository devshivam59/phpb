<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || isAdmin()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);

$success = '';
$error = '';

// Handle deposit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'deposit') {
    $amount = floatval($_POST['amount']);
    $transaction_id = sanitize($_POST['transaction_id']);
    $upi_id = sanitize($_POST['upi_id']);
    
    if ($amount < 100) {
        $error = 'Minimum deposit amount is ₹100';
    } else {
        $conn = getDBConnection();
        $stmt = $conn->prepare("INSERT INTO deposits (user_id, amount, payment_method, transaction_id, upi_id) VALUES (?, ?, 'UPI', ?, ?)");
        $stmt->bind_param("idss", $user_id, $amount, $transaction_id, $upi_id);
        
        if ($stmt->execute()) {
            $success = 'Deposit request submitted! Waiting for admin approval.';
        } else {
            $error = 'Failed to submit deposit request';
        }
        
        $stmt->close();
        $conn->close();
    }
}

// Handle withdrawal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'withdraw') {
    $amount = floatval($_POST['amount']);
    
    if ($amount < 500) {
        $error = 'Minimum withdrawal amount is ₹500';
    } elseif ($amount > $balance) {
        $error = 'Insufficient balance';
    } else {
        $bank_name = $user['bank_name'] ?: 'Not Set';
        $account_number = $user['account_number'] ?: 'Not Set';
        $ifsc_code = $user['ifsc_code'] ?: 'Not Set';
        
        if ($bank_name === 'Not Set') {
            $error = 'Please update your bank details in profile first';
        } else {
            $conn = getDBConnection();
            $stmt = $conn->prepare("INSERT INTO withdrawals (user_id, amount, bank_name, account_number, ifsc_code) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("idsss", $user_id, $amount, $bank_name, $account_number, $ifsc_code);
            
            if ($stmt->execute()) {
                $success = 'Withdrawal request submitted! Waiting for admin approval.';
            } else {
                $error = 'Failed to submit withdrawal request';
            }
            
            $stmt->close();
            $conn->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Funds - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/mobile-style.css">
</head>
<body>
    <div class="main-content">
        <div class="header">
            <div class="header-content">
                <div style="font-size: 1.2rem; font-weight: 600;"><i class="fas fa-wallet"></i> Funds</div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; opacity: 0.9;">Balance</div>
                    <div class="balance-amount"><?php echo formatCurrency($balance); ?></div>
                </div>
            </div>
        </div>
        
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Quick Actions -->
            <div class="action-buttons">
                <button class="action-btn deposit" onclick="openDepositModal()">
                    <i class="fas fa-arrow-down"></i>
                    <div>Deposit Money</div>
                </button>
                <button class="action-btn withdraw" onclick="openWithdrawModal()">
                    <i class="fas fa-arrow-up"></i>
                    <div>Withdraw Money</div>
                </button>
            </div>

            <!-- Recent Transactions -->
            <div class="card">
                <div style="font-size: 1.1rem; font-weight: 600; margin-bottom: 15px;"><i class="fas fa-list"></i> Recent Transactions</div>
                <?php
                $conn = getDBConnection();
                $stmt = $conn->prepare("
                    (SELECT 'deposit' as type, amount, status, created_at FROM deposits WHERE user_id = ? ORDER BY created_at DESC LIMIT 5)
                    UNION ALL
                    (SELECT 'withdrawal' as type, amount, status, created_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC LIMIT 5)
                    ORDER BY created_at DESC LIMIT 10
                ");
                $stmt->bind_param("ii", $user_id, $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0):
                    while ($row = $result->fetch_assoc()):
                        // Determine icon and label based on transaction type
                        if ($row['type'] === 'deposit' || $row['type'] === 'admin_credit') {
                            $icon = '<i class="fas fa-arrow-down" style="color: var(--success);"></i>';
                            $typeLabel = $row['type'] === 'admin_credit' ? 'Admin Credit' : 'Deposit';
                        } else {
                            $icon = '<i class="fas fa-arrow-up" style="color: var(--danger);"></i>';
                            $typeLabel = $row['type'] === 'admin_debit' ? 'Admin Debit' : 'Withdrawal';
                        }
                ?>
                    <div style="display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <div>
                            <div style="font-weight: 600;"><?php echo $icon; ?> <span style="margin-left: 8px;"><?php echo $typeLabel; ?></span></div>
                            <div style="font-size: 0.8rem; color: var(--text-secondary);"><?php echo date('d M Y, h:i A', strtotime($row['created_at'])); ?></div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: 600;">₹<?php echo number_format($row['amount'], 2); ?></div>
                            <div><span class="status-badge status-<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></span></div>
                        </div>
                    </div>
                <?php 
                    endwhile;
                else:
                ?>
                    <div style="text-align: center; padding: 20px; color: var(--text-secondary);">No transactions yet</div>
                <?php endif; 
                $stmt->close();
                $conn->close();
                ?>
            </div>
        </div>

        <!-- Bottom Navigation -->
        <div class="bottom-nav">
            <a href="dashboard.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-home"></i></div>
                <div class="nav-label">Home</div>
            </a>
            <a href="positions.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="nav-label">Positions</div>
            </a>
            <a href="funds.php" class="nav-item active">
                <div class="nav-icon"><i class="fas fa-wallet"></i></div>
                <div class="nav-label">Funds</div>
            </a>
            <a href="profile.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-user"></i></div>
                <div class="nav-label">Profile</div>
            </a>
        </div>
    </div>

    <!-- Deposit Modal -->
    <div id="depositModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-arrow-down"></i> Deposit Money</h2>
                <button class="modal-close" onclick="closeModal('depositModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="deposit">
                
                <?php
                // Get global payment QR code from admin settings
                $qr_conn = getDBConnection();
                $qr_stmt = $qr_conn->prepare("SELECT setting_value FROM admin_settings WHERE setting_key='payment_qr_code'");
                $qr_stmt->execute();
                $qr_result = $qr_stmt->get_result();
                $payment_qr = $qr_result->num_rows > 0 ? $qr_result->fetch_assoc()['setting_value'] : null;
                $qr_stmt->close();
                
                // Get UPI details
                $upi_stmt = $qr_conn->prepare("SELECT setting_key, setting_value FROM admin_settings WHERE setting_key IN ('upi_id', 'upi_name')");
                $upi_stmt->execute();
                $upi_result = $upi_stmt->get_result();
                $upi_settings = [];
                while ($row = $upi_result->fetch_assoc()) {
                    $upi_settings[$row['setting_key']] = $row['setting_value'];
                }
                $upi_stmt->close();
                $qr_conn->close();
                
                $upi_id = $upi_settings['upi_id'] ?? UPI_ID;
                $upi_name = $upi_settings['upi_name'] ?? UPI_NAME;
                ?>
                
                <?php if ($payment_qr && file_exists(__DIR__ . '/../uploads/qr_codes/' . $payment_qr)): ?>
                    <div style="text-align: center; margin-bottom: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 15px;">
                        <h4 style="margin-bottom: 15px; color: white; font-weight: 600;"><i class="fas fa-qrcode"></i> Scan QR Code to Pay</h4>
                        <div style="background: white; padding: 15px; border-radius: 10px; display: inline-block;">
                            <img src="../uploads/qr_codes/<?php echo $payment_qr; ?>" alt="Payment QR Code" style="max-width: 250px; border-radius: 8px;">
                        </div>
                        <p style="margin-top: 15px; color: white; font-size: 0.9rem;"><i class="fas fa-mobile-alt"></i> Scan with any UPI app to make payment</p>
                        <div style="background: rgba(255,255,255,0.2); padding: 10px; border-radius: 8px; margin-top: 10px;">
                            <p style="color: white; font-size: 0.85rem; margin: 0;"><strong>UPI ID:</strong> <?php echo htmlspecialchars($upi_id); ?></p>
                            <p style="color: white; font-size: 0.85rem; margin: 5px 0 0 0;"><strong>Name:</strong> <?php echo htmlspecialchars($upi_name); ?></p>
                        </div>
                    </div>
                <?php else: ?>
                    <div style="background: #fff3cd; border: 2px solid #ffc107; border-radius: 10px; padding: 20px; margin-bottom: 20px; text-align: center;">
                        <i class="fas fa-exclamation-triangle" style="font-size: 2rem; color: #ffc107; margin-bottom: 10px;"></i>
                        <h4 style="color: #856404; margin-bottom: 15px;">Payment Details</h4>
                        <div style="background: white; padding: 15px; border-radius: 8px;">
                            <p style="margin: 5px 0; color: #333;"><strong><i class="fas fa-at"></i> UPI ID:</strong> <?php echo htmlspecialchars($upi_id); ?></p>
                            <p style="margin: 5px 0; color: #333;"><strong><i class="fas fa-user"></i> Name:</strong> <?php echo htmlspecialchars($upi_name); ?></p>
                        </div>
                        <p style="color: #856404; font-size: 0.85rem; margin-top: 15px;"><i class="fas fa-info-circle"></i> QR code not available. Please use the UPI ID above to make payment.</p>
                    </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label class="form-label">Amount (Min ₹100) *</label>
                    <input type="number" name="amount" class="form-control" min="100" step="0.01" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Your UPI ID *</label>
                    <input type="text" name="upi_id" class="form-control" placeholder="yourname@upi" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Transaction ID *</label>
                    <input type="text" name="transaction_id" class="form-control" placeholder="Enter UTR/Transaction ID" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Submit Deposit Request</button>
            </form>
        </div>
    </div>

    <!-- Withdraw Modal -->
    <div id="withdrawModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2><i class="fas fa-arrow-up"></i> Withdraw Money</h2>
                <button class="modal-close" onclick="closeModal('withdrawModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="withdraw">
                
                <div class="alert alert-info">
                    Available Balance: <strong><?php echo formatCurrency($balance); ?></strong>
                </div>
                
                <?php if (!$user['bank_name']): ?>
                    <div class="alert alert-danger">
                        Please update your bank details in profile first!
                    </div>
                <?php else: ?>
                    <div style="background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 15px; font-size: 0.85rem;">
                        <strong>Bank:</strong> <?php echo $user['bank_name']; ?><br>
                        <strong>A/C:</strong> <?php echo $user['account_number']; ?><br>
                        <strong>IFSC:</strong> <?php echo $user['ifsc_code']; ?>
                    </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label class="form-label">Amount (Min ₹500) *</label>
                    <input type="number" name="amount" class="form-control" min="500" max="<?php echo $balance; ?>" step="0.01" required>
                </div>
                
                <button type="submit" class="btn btn-primary" <?php echo !$user['bank_name'] ? 'disabled' : ''; ?>>
                    Submit Withdrawal Request
                </button>
            </form>
        </div>
    </div>

    <script>
        function openDepositModal() {
            document.getElementById('depositModal').classList.add('active');
        }
        
        function openWithdrawModal() {
            document.getElementById('withdrawModal').classList.add('active');
        }
        
        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>
