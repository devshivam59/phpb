<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || isAdmin()) redirect('index.php');
$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);

$conn = getDBConnection();

// Get total P&L
$stmt = $conn->prepare("SELECT SUM(profit_loss) as total_pnl, 
                        SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) as open_count,
                        SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END) as closed_count
                        FROM positions WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pnl_summary = $stmt->get_result()->fetch_assoc();
$stmt->close();

$total_pnl = $pnl_summary['total_pnl'] ?? 0;
$open_count = $pnl_summary['open_count'] ?? 0;
$closed_count = $pnl_summary['closed_count'] ?? 0;

// Get all positions
$stmt = $conn->prepare("SELECT * FROM positions WHERE user_id = ? ORDER BY entry_date DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$positions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Positions</title>
    <link rel="stylesheet" href="../assets/css/mobile-style.css">
</head>
<body>
    <div class="main-content">
        <div class="header">
            <div class="header-content">
                <div style="font-size: 1.2rem; font-weight: 600;"><i class="fas fa-chart-bar"></i> Positions</div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; opacity: 0.9;">Balance</div>
                    <div class="balance-amount"><?php echo formatCurrency($balance); ?></div>
                </div>
            </div>
        </div>
        <div class="content">
            <!-- Total P&L Summary -->
            <div class="card">
                <div class="card-title"><i class="fas fa-chart-pie"></i> P&L Summary</div>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px;">
                    <div style="background: linear-gradient(135deg, <?php echo $total_pnl >= 0 ? 'rgba(16,185,129,0.1), rgba(5,150,105,0.05)' : 'rgba(239,68,68,0.1), rgba(220,38,38,0.05)'; ?>); padding: 15px; border-radius: 12px; border: 1px solid <?php echo $total_pnl >= 0 ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)'; ?>; grid-column: span 3;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px; text-align: center;">Total P&L</div>
                        <div style="font-size: 1.8rem; font-weight: bold; text-align: center;" class="<?php echo $total_pnl >= 0 ? 'price-up' : 'price-down'; ?>">
                            <?php echo $total_pnl >= 0 ? '+' : ''; ?><?php echo formatCurrency($total_pnl); ?>
                        </div>
                    </div>
                    <div style="background: rgba(245,158,11,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(245,158,11,0.2); text-align: center;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Open</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: var(--warning);"><?php echo $open_count; ?></div>
                    </div>
                    <div style="background: rgba(107,114,128,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(107,114,128,0.2); text-align: center;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Closed</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: var(--text-secondary);"><?php echo $closed_count; ?></div>
                    </div>
                    <div style="background: rgba(59,130,246,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(59,130,246,0.2); text-align: center;">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Total</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: #3b82f6;"><?php echo $open_count + $closed_count; ?></div>
                    </div>
                </div>
            </div>

            <!-- Positions List -->
            <?php if (empty($positions)): ?>
                <div class="card" style="text-align: center; padding: 40px;">
                    <div class="empty-state"><i class="fas fa-chart-bar"></i></div>
                    <div style="color: var(--text-secondary); margin-top: 15px;">No positions yet</div>
                </div>
            <?php else: ?>
                <?php foreach ($positions as $pos): ?>
                    <div class="card">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                            <div>
                                <div style="font-size: 1.2rem; font-weight: 600;"><?php echo $pos['symbol']; ?></div>
                                <div style="font-size: 0.85rem; color: var(--text-secondary);">
                                    <i class="fas fa-<?php echo $pos['trade_type'] === 'buy' ? 'arrow-up' : 'arrow-down'; ?>"></i>
                                    <?php echo strtoupper($pos['trade_type']); ?> • Qty: <?php echo $pos['quantity']; ?>
                                </div>
                            </div>
                            <div>
                                <span class="status-badge status-<?php echo $pos['status']; ?>">
                                    <?php echo ucfirst($pos['status']); ?>
                                </span>
                            </div>
                        </div>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; padding: 12px; background: rgba(255,255,255,0.03); border-radius: 8px;">
                            <div>
                                <div style="font-size: 0.75rem; color: var(--text-secondary);">Entry Price</div>
                                <div style="font-weight: 600;">₹<?php echo number_format($pos['entry_price'], 2); ?></div>
                            </div>
                            <?php if ($pos['status'] === 'closed'): ?>
                                <div>
                                    <div style="font-size: 0.75rem; color: var(--text-secondary);">Exit Price</div>
                                    <div style="font-weight: 600;">₹<?php echo number_format($pos['exit_price'], 2); ?></div>
                                </div>
                                <div style="grid-column: span 2;">
                                    <div style="font-size: 0.75rem; color: var(--text-secondary);">Profit/Loss</div>
                                    <div style="font-size: 1.2rem; font-weight: bold;" class="<?php echo $pos['profit_loss'] >= 0 ? 'price-up' : 'price-down'; ?>">
                                        <?php echo $pos['profit_loss'] >= 0 ? '+' : ''; ?><?php echo formatCurrency($pos['profit_loss']); ?>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div>
                                    <div style="font-size: 0.75rem; color: var(--text-secondary);">Current Price</div>
                                    <div style="font-weight: 600;">--</div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 10px;">
                            <i class="fas fa-clock"></i> Entry: <?php echo date('d M Y, h:i A', strtotime($pos['entry_date'])); ?>
                            <?php if ($pos['status'] === 'closed' && $pos['exit_date']): ?>
                                <br><i class="fas fa-check"></i> Exit: <?php echo date('d M Y, h:i A', strtotime($pos['exit_date'])); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="bottom-nav">
            <a href="dashboard.php" class="nav-item"><div class="nav-icon"><i class="fas fa-home"></i></div><div class="nav-label">Home</div></a>
            <a href="positions.php" class="nav-item active"><div class="nav-icon"><i class="fas fa-chart-bar"></i></div><div class="nav-label">Positions</div></a>
            <a href="funds.php" class="nav-item"><div class="nav-icon"><i class="fas fa-wallet"></i></div><div class="nav-label">Funds</div></a>
            <a href="profile.php" class="nav-item"><div class="nav-icon"><i class="fas fa-user"></i></div><div class="nav-label">Profile</div></a>
        </div>
    </div>
</body>
</html>
