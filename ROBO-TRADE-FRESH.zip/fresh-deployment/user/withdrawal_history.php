<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || isAdmin()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);
$notifications_count = getUnreadNotificationsCount($user_id);

// Get withdrawals
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT * FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$withdrawals = [];
while ($row = $result->fetch_assoc()) {
    $withdrawals[] = $row;
}
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawal History - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Withdrawal History</h1>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Withdrawals</h2>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Amount</th>
                                <th>Bank Details</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Admin Note</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($withdrawals)): ?>
                                <tr>
                                    <td colspan="6" style="text-align: center;">No withdrawals found</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($withdrawals as $index => $withdrawal): ?>
                                    <tr>
                                        <td><?php echo $index + 1; ?></td>
                                        <td><strong><?php echo formatCurrency($withdrawal['amount']); ?></strong></td>
                                        <td>
                                            <strong><?php echo $withdrawal['bank_name']; ?></strong><br>
                                            <small style="color: var(--text-secondary);">
                                                A/C: <?php echo $withdrawal['account_number']; ?><br>
                                                IFSC: <?php echo $withdrawal['ifsc_code']; ?>
                                            </small>
                                        </td>
                                        <td><?php echo formatDateTime($withdrawal['created_at']); ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $withdrawal['status']; ?>">
                                                <?php echo ucfirst($withdrawal['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($withdrawal['admin_note']): ?>
                                                <small style="color: var(--text-secondary);"><?php echo $withdrawal['admin_note']; ?></small>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

