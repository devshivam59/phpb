<div class="header">
    <div class="header-search">
        <input type="text" placeholder="Search...">
    </div>
    
    <div class="header-actions">
        <div class="header-icon">
            <span>🔔</span>
            <?php if ($notifications_count > 0): ?>
                <span class="badge"><?php echo $notifications_count; ?></span>
            <?php endif; ?>
        </div>
        
        <div class="user-profile">
            <?php if (!empty($user['profile_image'])): ?>
                <img src="../uploads/profiles/<?php echo $user['profile_image']; ?>" alt="Profile" class="user-avatar">
            <?php else: ?>
                <div class="user-avatar" style="background: var(--primary-color); display: flex; align-items: center; justify-content: center; font-weight: bold;">
                    <?php echo strtoupper(substr($user['first_name'], 0, 1)); ?>
                </div>
            <?php endif; ?>
            <span><?php echo $user['first_name']; ?></span>
        </div>
    </div>
</div>

