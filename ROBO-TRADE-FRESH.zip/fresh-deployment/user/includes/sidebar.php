<div class="sidebar">
    <div class="sidebar-logo">
        <h2>Robo Trade</h2>
    </div>
    
    <ul class="sidebar-menu">
        <li>
            <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                <span class="icon">📊</span>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="funds.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'funds.php' ? 'active' : ''; ?>">
                <span class="icon">💰</span>
                <span>Funds</span>
            </a>
        </li>
        <li>
            <a href="positions.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'positions.php' ? 'active' : ''; ?>">
                <span class="icon">📈</span>
                <span>Positions</span>
            </a>
        </li>
        <li>
            <a href="deposit_history.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'deposit_history.php' ? 'active' : ''; ?>">
                <span class="icon">💳</span>
                <span>Deposit History</span>
            </a>
        </li>
        <li>
            <a href="withdrawal_history.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'withdrawal_history.php' ? 'active' : ''; ?>">
                <span class="icon">🏦</span>
                <span>Withdrawal History</span>
            </a>
        </li>
        <li>
            <a href="profile.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'profile.php' ? 'active' : ''; ?>">
                <span class="icon">⚙️</span>
                <span>Account</span>
            </a>
        </li>
        <li>
            <a href="logout.php">
                <span class="icon">🚪</span>
                <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

