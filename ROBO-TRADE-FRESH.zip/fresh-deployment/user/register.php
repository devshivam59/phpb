<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    
    // Sanitize inputs
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $dob = $_POST['dob'];
    $pan_number = strtoupper(trim($_POST['pan_number']));
    $aadhar_number = trim($_POST['aadhar_number']);
    $bank_name = trim($_POST['bank_name']);
    $account_number = trim($_POST['account_number']);
    $ifsc_code = strtoupper(trim($_POST['ifsc_code']));
    $account_holder_name = trim($_POST['account_holder_name']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone)) {
        $error = 'Please fill all required fields';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (strlen($phone) != 10 || !ctype_digit($phone)) {
        $error = 'Phone number must be 10 digits';
    } elseif (strlen($pan_number) != 10) {
        $error = 'PAN number must be 10 characters';
    } elseif (strlen($aadhar_number) != 12 || !ctype_digit($aadhar_number)) {
        $error = 'Aadhaar number must be 12 digits';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match';
    } else {
        // Check if email or phone already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email=? OR phone=?");
        $stmt->bind_param("ss", $email, $phone);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $error = 'Email or phone number already registered';
        } else {
            // Check if already requested
            $stmt = $conn->prepare("SELECT id FROM registration_requests WHERE email=? OR phone=?");
            $stmt->bind_param("ss", $email, $phone);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $error = 'Registration request already submitted. Please wait for admin approval.';
            } else {
                // Generate user ID
                $user_id_requested = 'USR' . str_pad(rand(1, 999999), 6, '0', STR_PAD_LEFT);
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Insert registration request
                $stmt = $conn->prepare("INSERT INTO registration_requests 
                    (user_id_requested, first_name, last_name, email, phone, address, dob, pan_number, 
                     aadhar_number, bank_name, account_number, ifsc_code, account_holder_name, password_hash) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("ssssssssssssss", 
                    $user_id_requested, $first_name, $last_name, $email, $phone, $address, $dob, 
                    $pan_number, $aadhar_number, $bank_name, $account_number, $ifsc_code, 
                    $account_holder_name, $password_hash);
                
                if ($stmt->execute()) {
                    $success = 'Registration request submitted successfully! Your User ID will be: ' . $user_id_requested . '. Please wait for admin approval.';
                } else {
                    $error = 'Failed to submit registration request';
                }
            }
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .register-container {
            max-width: 600px;
            margin: 20px auto;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .register-header h1 {
            color: #667eea;
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .register-header p {
            color: #666;
            font-size: 0.9rem;
        }
        .form-section {
            margin-bottom: 25px;
        }
        .section-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .form-group label .required {
            color: #e74c3c;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 0.95rem;
            transition: all 0.3s;
        }
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102,126,234,0.1);
        }
        textarea.form-control {
            resize: vertical;
            min-height: 80px;
        }
        .btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
        }
        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .login-link {
            text-align: center;
            margin-top: 20px;
            color: #666;
        }
        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            .register-container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h1><i class="fas fa-user-plus"></i> User Registration</h1>
            <p>Fill in your details to create an account. Admin will review and approve your request.</p>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            <!-- Personal Information -->
            <div class="form-section">
                <div class="section-title"><i class="fas fa-user"></i> Personal Information</div>
                <div class="form-row">
                    <div class="form-group">
                        <label>First Name <span class="required">*</span></label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name <span class="required">*</span></label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Mobile Number <span class="required">*</span></label>
                        <input type="tel" name="phone" class="form-control" pattern="[0-9]{10}" maxlength="10" placeholder="10 digits" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Date of Birth <span class="required">*</span></label>
                    <input type="date" name="dob" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Address <span class="required">*</span></label>
                    <textarea name="address" class="form-control" required></textarea>
                </div>
            </div>

            <!-- KYC Documents -->
            <div class="form-section">
                <div class="section-title"><i class="fas fa-id-card"></i> KYC Documents</div>
                <div class="form-row">
                    <div class="form-group">
                        <label>PAN Number <span class="required">*</span></label>
                        <input type="text" name="pan_number" class="form-control" maxlength="10" placeholder="ABCDE1234F" style="text-transform: uppercase;" required>
                    </div>
                    <div class="form-group">
                        <label>Aadhaar Number <span class="required">*</span></label>
                        <input type="text" name="aadhar_number" class="form-control" pattern="[0-9]{12}" maxlength="12" placeholder="12 digits" required>
                    </div>
                </div>
            </div>

            <!-- Bank Details -->
            <div class="form-section">
                <div class="section-title"><i class="fas fa-university"></i> Bank Details</div>
                <div class="form-group">
                    <label>Account Holder Name <span class="required">*</span></label>
                    <input type="text" name="account_holder_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Bank Name <span class="required">*</span></label>
                    <input type="text" name="bank_name" class="form-control" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Account Number <span class="required">*</span></label>
                        <input type="text" name="account_number" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>IFSC Code <span class="required">*</span></label>
                        <input type="text" name="ifsc_code" class="form-control" maxlength="11" style="text-transform: uppercase;" required>
                    </div>
                </div>
            </div>

            <!-- Password -->
            <div class="form-section">
                <div class="section-title"><i class="fas fa-lock"></i> Create Password</div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Password <span class="required">*</span></label>
                        <input type="password" name="password" class="form-control" minlength="6" required>
                    </div>
                    <div class="form-group">
                        <label>Confirm Password <span class="required">*</span></label>
                        <input type="password" name="confirm_password" class="form-control" minlength="6" required>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-paper-plane"></i> Submit Registration Request
            </button>
        </form>

        <div class="login-link">
            Already have an account? <a href="index.php"><i class="fas fa-sign-in-alt"></i> Login Here</a>
        </div>
    </div>
</body>
</html>
