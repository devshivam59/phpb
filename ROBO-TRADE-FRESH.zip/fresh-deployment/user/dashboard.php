<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || isAdmin()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];
$user = getUserData($user_id);
$balance = getUserBalance($user_id);

// Calculate total P&L
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT SUM(profit_loss) as total_pnl, COUNT(*) as total_trades, 
                        SUM(CASE WHEN status='open' THEN 1 ELSE 0 END) as open_trades,
                        SUM(CASE WHEN status='closed' THEN 1 ELSE 0 END) as closed_trades
                        FROM positions WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$pnl_data = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

$total_pnl = $pnl_data['total_pnl'] ?? 0;
$total_trades = $pnl_data['total_trades'] ?? 0;
$open_trades = $pnl_data['open_trades'] ?? 0;
$closed_trades = $pnl_data['closed_trades'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../assets/css/mobile-style.css">
</head>
<body>
    <div class="main-content">
        <div class="header">
            <div class="header-content">
                <div>
                    <div style="font-size: 0.85rem; opacity: 0.9;">Welcome back,</div>
                    <div style="font-size: 1.2rem; font-weight: 600;"><?php echo $user['first_name']; ?></div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 0.75rem; opacity: 0.9;">Balance</div>
                    <div class="balance-amount"><?php echo formatCurrency($balance); ?></div>
                </div>
            </div>
        </div>
        
        <div class="content">
            <!-- Portfolio Summary -->
            <div class="card">
                <div class="card-title"><i class="fas fa-chart-pie"></i> Portfolio Summary</div>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
                    <div style="background: linear-gradient(135deg, rgba(16,185,129,0.1), rgba(5,150,105,0.05)); padding: 15px; border-radius: 12px; border: 1px solid rgba(16,185,129,0.2);">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Total P&L</div>
                        <div style="font-size: 1.3rem; font-weight: bold;" class="<?php echo $total_pnl >= 0 ? 'price-up' : 'price-down'; ?>">
                            <?php echo $total_pnl >= 0 ? '+' : ''; ?><?php echo formatCurrency($total_pnl); ?>
                        </div>
                    </div>
                    <div style="background: rgba(59,130,246,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(59,130,246,0.2);">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Total Trades</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: #3b82f6;"><?php echo $total_trades; ?></div>
                    </div>
                    <div style="background: rgba(245,158,11,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(245,158,11,0.2);">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Open Positions</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: var(--warning);"><?php echo $open_trades; ?></div>
                    </div>
                    <div style="background: rgba(107,114,128,0.1); padding: 15px; border-radius: 12px; border: 1px solid rgba(107,114,128,0.2);">
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-bottom: 5px;">Closed Trades</div>
                        <div style="font-size: 1.3rem; font-weight: bold; color: var(--text-secondary);"><?php echo $closed_trades; ?></div>
                    </div>
                </div>
            </div>

            <!-- Market Indices -->
            <div class="card">
                <div class="card-title"><i class="fas fa-chart-line"></i> Market Indices</div>
                <div class="index-grid" id="indicesGrid">
                    <div class="index-card">
                        <div class="index-name">NIFTY 50</div>
                        <div class="index-price" id="nifty_price">Loading...</div>
                        <div class="index-change" id="nifty_change">--</div>
                    </div>
                    <div class="index-card">
                        <div class="index-name">BANK NIFTY</div>
                        <div class="index-price" id="banknifty_price">Loading...</div>
                        <div class="index-change" id="banknifty_change">--</div>
                    </div>
                    <div class="index-card">
                        <div class="index-name">SENSEX</div>
                        <div class="index-price" id="sensex_price">Loading...</div>
                        <div class="index-change" id="sensex_change">--</div>
                    </div>
                    <div class="index-card">
                        <div class="index-name">FIN NIFTY</div>
                        <div class="index-price" id="finnifty_price">Loading...</div>
                        <div class="index-change" id="finnifty_change">--</div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card">
                <div class="card-title"><i class="fas fa-bolt"></i> Quick Actions</div>
                <div class="action-buttons">
                    <button class="action-btn deposit" onclick="window.location.href='funds.php'">
                        <i class="fas fa-arrow-down"></i>
                        <div>Deposit</div>
                    </button>
                    <button class="action-btn withdraw" onclick="window.location.href='funds.php'">
                        <i class="fas fa-arrow-up"></i>
                        <div>Withdraw</div>
                    </button>
                </div>
            </div>

            <!-- Top Stocks -->
            <div class="card">
                <div class="card-title"><i class="fas fa-fire"></i> Top Stocks</div>
                <div id="stocksList">
                    <div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading stocks...</div>
                </div>
            </div>
        </div>

        <!-- Bottom Navigation -->
        <div class="bottom-nav">
            <a href="dashboard.php" class="nav-item active">
                <div class="nav-icon"><i class="fas fa-home"></i></div>
                <div class="nav-label">Home</div>
            </a>
            <a href="positions.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="nav-label">Positions</div>
            </a>
            <a href="funds.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-wallet"></i></div>
                <div class="nav-label">Funds</div>
            </a>
            <a href="profile.php" class="nav-item">
                <div class="nav-icon"><i class="fas fa-user"></i></div>
                <div class="nav-label">Profile</div>
            </a>
        </div>
    </div>

    <script>
        function updatePrices() {
            fetch('../api/get_indices.php')
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        updateIndex('nifty', data.data.nifty);
                        updateIndex('banknifty', data.data.banknifty);
                        updateIndex('sensex', data.data.sensex);
                        updateIndex('finnifty', data.data.finnifty);
                    }
                })
                .catch(err => console.error('Error fetching indices:', err));

            fetch('../api/get_stock_data.php?sector=nifty50&limit=5')
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.data.length > 0) {
                        let html = '';
                        data.data.forEach(stock => {
                            const changeClass = stock.change >= 0 ? 'price-up' : 'price-down';
                            const changeIcon = stock.change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
                            html += `
                                <div class="stock-item">
                                    <div>
                                        <div style="font-weight: 600;">${stock.symbol}</div>
                                        <div style="font-size: 0.8rem; color: var(--text-secondary);">Vol: ${stock.volume}</div>
                                    </div>
                                    <div style="text-align: right;">
                                        <div style="font-weight: 600;">₹${stock.ltp.toFixed(2)}</div>
                                        <div class="${changeClass}" style="font-size: 0.85rem;">
                                            <i class="fas ${changeIcon}"></i> ${Math.abs(stock.change).toFixed(2)}%
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        document.getElementById('stocksList').innerHTML = html;
                    }
                })
                .catch(err => {
                    console.error('Error fetching stocks:', err);
                });
        }

        function updateIndex(name, data) {
            const priceEl = document.getElementById(name + '_price');
            const changeEl = document.getElementById(name + '_change');
            
            if (priceEl && changeEl) {
                priceEl.textContent = '₹' + data.price.toFixed(2);
                const changeClass = data.change >= 0 ? 'price-up' : 'price-down';
                const changeIcon = data.change >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
                changeEl.innerHTML = `<i class="fas ${changeIcon}"></i> <span class="${changeClass}">${Math.abs(data.change).toFixed(2)}%</span>`;
            }
        }

        updatePrices();
        setInterval(updatePrices, 5000);
    </script>
</body>
</html>
