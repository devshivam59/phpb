<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/api_handler.php';

$api = new MarketDataAPI();

$nifty = $api->getIndexData('NIFTY 50');
$banknifty = $api->getIndexData('NIFTY BANK');
$sensex = $api->getIndexData('SENSEX');
$finnifty = $api->getIndexData('NIFTY FIN SERVICE');

$response = [
    'success' => true,
    'data' => [
        'nifty' => [
            'price' => $nifty['last'],
            'change' => $nifty['percentChange']
        ],
        'banknifty' => [
            'price' => $banknifty['last'],
            'change' => $banknifty['percentChange']
        ],
        'sensex' => [
            'price' => $sensex['last'],
            'change' => $sensex['percentChange']
        ],
        'finnifty' => [
            'price' => $finnifty['last'],
            'change' => $finnifty['percentChange']
        ]
    ]
];

echo json_encode($response);
?>
