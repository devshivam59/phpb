<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/api_handler.php';

$sector = strtoupper($_GET['sector'] ?? 'nifty50');
$limit = intval($_GET['limit'] ?? 10);

// Map sector names
$sectorMap = [
    'NIFTY50' => 'NIFTY 50',
    'NIFTYBANK' => 'NIFTY BANK',
    'NIFTYIT' => 'NIFTY IT',
    'NIFTYENERGY' => 'NIFTY ENERGY',
    'NIFTYAUTO' => 'NIFTY AUTO'
];

$mappedSector = $sectorMap[$sector] ?? 'NIFTY BANK';

$api = new MarketDataAPI();
$stocks = $api->getSectorStocks($mappedSector);

// Convert to array and limit
$stocksArray = array_values($stocks);
$stocksArray = array_slice($stocksArray, 0, $limit);

// Format for frontend
$formatted = array_map(function($stock) {
    return [
        'symbol' => $stock['symbol'],
        'ltp' => $stock['ltp'],
        'change' => $stock['pChange'],
        'volume' => $stock['volume']
    ];
}, $stocksArray);

echo json_encode([
    'success' => true,
    'data' => $formatted
]);
?>
