<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check if user is admin
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Redirect function
function redirect($url) {
    header("Location: $url");
    exit();
}

// Get user data
function getUserData($user_id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    return $user;
}

// Get user balance
function getUserBalance($user_id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT balance FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    return $row['balance'] ?? 0;
}

// Update user balance
function updateUserBalance($user_id, $amount, $operation = 'add') {
    $conn = getDBConnection();
    
    if ($operation === 'add') {
        $sql = "UPDATE users SET balance = balance + ? WHERE id = ?";
    } else {
        $sql = "UPDATE users SET balance = balance - ? WHERE id = ?";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("di", $amount, $user_id);
    $success = $stmt->execute();
    $stmt->close();
    $conn->close();
    
    return $success;
}

// Create notification
function createNotification($user_id, $title, $message, $type = 'system') {
    $conn = getDBConnection();
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $user_id, $title, $message, $type);
    $success = $stmt->execute();
    $stmt->close();
    $conn->close();
    return $success;
}

// Get unread notifications count
function getUnreadNotificationsCount($user_id) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    return $row['count'] ?? 0;
}

// Get recent notifications
function getRecentNotifications($user_id, $limit = 10) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->bind_param("ii", $user_id, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = [];
    while ($row = $result->fetch_assoc()) {
        $notifications[] = $row;
    }
    $stmt->close();
    $conn->close();
    return $notifications;
}

// Log admin action
function logAdminAction($admin_id, $action, $target_user_id = null, $details = null) {
    $conn = getDBConnection();
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $stmt = $conn->prepare("INSERT INTO admin_logs (admin_id, action, target_user_id, details, ip_address) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isiss", $admin_id, $action, $target_user_id, $details, $ip_address);
    $success = $stmt->execute();
    $stmt->close();
    $conn->close();
    return $success;
}

// Format currency
function formatCurrency($amount) {
    return '₹' . number_format($amount, 2);
}

// Format date
function formatDate($date) {
    return date('d M Y', strtotime($date));
}

// Format datetime
function formatDateTime($datetime) {
    return date('d M Y h:i A', strtotime($datetime));
}

// Upload file
function uploadFile($file, $upload_path, $allowed_types = null) {
    if ($allowed_types === null) {
        $allowed_types = ALLOWED_IMAGE_TYPES;
    }
    
    if (!in_array($file['type'], $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'message' => 'File size exceeds limit'];
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $destination = $upload_path . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return ['success' => true, 'filename' => $filename];
    }
    
    return ['success' => false, 'message' => 'Failed to upload file'];
}

// Generate CSRF token
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Verify CSRF token
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Calculate profit/loss
function calculateProfitLoss($trade_type, $entry_price, $exit_price, $quantity) {
    if ($trade_type === 'buy') {
        return ($exit_price - $entry_price) * $quantity;
    } else {
        return ($entry_price - $exit_price) * $quantity;
    }
}

// Get status badge class
function getStatusBadgeClass($status) {
    $classes = [
        'pending' => 'badge-warning',
        'approved' => 'badge-success',
        'rejected' => 'badge-danger',
        'active' => 'badge-success',
        'suspended' => 'badge-warning',
        'blocked' => 'badge-danger',
        'open' => 'badge-info',
        'closed' => 'badge-secondary',
        'processing' => 'badge-warning',
        'completed' => 'badge-success'
    ];
    
    return $classes[$status] ?? 'badge-secondary';
}

// Pagination helper
function paginate($total_records, $current_page, $records_per_page = RECORDS_PER_PAGE) {
    $total_pages = ceil($total_records / $records_per_page);
    $offset = ($current_page - 1) * $records_per_page;
    
    return [
        'total_pages' => $total_pages,
        'current_page' => $current_page,
        'offset' => $offset,
        'limit' => $records_per_page
    ];
}

// Generate user ID
function generateUserId($prefix = 'USR') {
    $conn = getDBConnection();
    $result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='user'");
    $row = $result->fetch_assoc();
    $count = $row['count'] + 1;
    $conn->close();
    
    return $prefix . str_pad($count, 7, '0', STR_PAD_LEFT);
}
?>

