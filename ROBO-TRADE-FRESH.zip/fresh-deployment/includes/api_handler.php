<?php
// Market Data API Handler
// Using NSE India API for live stock prices

class MarketDataAPI {
    private $base_url = 'https://www.nseindia.com/api';
    private $headers = [];
    
    public function __construct() {
        $this->headers = [
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept: application/json',
            'Accept-Language: en-US,en;q=0.9',
            'Accept-Encoding: gzip, deflate, br'
        ];
    }
    
    // Get index data (Nifty, Bank Nifty, etc.)
    public function getIndexData($index = 'NIFTY 50') {
        $url = $this->base_url . '/allIndices';
        $data = $this->makeRequest($url);
        
        if ($data && isset($data['data'])) {
            foreach ($data['data'] as $idx) {
                if ($idx['index'] === $index) {
                    return [
                        'name' => $idx['index'],
                        'last' => $idx['last'] ?? 0,
                        'change' => $idx['variation'] ?? 0,
                        'percentChange' => $idx['percentChange'] ?? 0
                    ];
                }
            }
        }
        
        return $this->getDummyIndexData($index);
    }
    
    // Get stock quote
    public function getStockQuote($symbol) {
        $url = $this->base_url . '/quote-equity?symbol=' . urlencode($symbol);
        $data = $this->makeRequest($url);
        
        if ($data && isset($data['priceInfo'])) {
            $priceInfo = $data['priceInfo'];
            return [
                'symbol' => $symbol,
                'ltp' => $priceInfo['lastPrice'] ?? 0,
                'change' => $priceInfo['change'] ?? 0,
                'pChange' => $priceInfo['pChange'] ?? 0,
                'open' => $priceInfo['open'] ?? 0,
                'high' => $priceInfo['intraDayHighLow']['max'] ?? 0,
                'low' => $priceInfo['intraDayHighLow']['min'] ?? 0,
                'volume' => $data['preOpenMarket']['totalTradedVolume'] ?? 0
            ];
        }
        
        return $this->getDummyStockData($symbol);
    }
    
    // Get multiple stocks data
    public function getMultipleStocks($symbols) {
        $results = [];
        foreach ($symbols as $symbol) {
            $results[$symbol] = $this->getStockQuote($symbol);
        }
        return $results;
    }
    
    // Get sector stocks
    public function getSectorStocks($sector) {
        $sectorSymbols = $this->getSectorSymbolsList($sector);
        return $this->getMultipleStocks($sectorSymbols);
    }
    
    // Make HTTP request
    private function makeRequest($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200 && $response) {
            return json_decode($response, true);
        }
        
        return null;
    }
    
    // Get sector symbols list
    private function getSectorSymbolsList($sector) {
        $sectors = [
            'NIFTY BANK' => ['AUBANK', 'AXISBANK', 'BANDHANBNK', 'BANKBARODA', 'FEDERALBNK', 'HDFCBANK', 'ICICIBANK', 'IDFCFIRSTB', 'INDUSINDBK', 'KOTAKBANK', 'PNB', 'SBIN'],
            'NIFTY 50' => ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK', 'HINDUNILVR', 'ITC', 'SBIN', 'BHARTIARTL', 'KOTAKBANK'],
            'NIFTY IT' => ['TCS', 'INFY', 'HCLTECH', 'WIPRO', 'TECHM', 'LTIM', 'COFORGE', 'PERSISTENT', 'MPHASIS', 'LTTS'],
            'NIFTY ENERGY' => ['RELIANCE', 'ONGC', 'NTPC', 'POWERGRID', 'COALINDIA', 'IOC', 'BPCL', 'ADANIGREEN', 'ADANITRANS', 'TATAPOWER'],
            'NIFTY AUTO' => ['MARUTI', 'M&M', 'TATAMOTORS', 'BAJAJ-AUTO', 'EICHERMOT', 'HEROMOTOCO', 'TVSMOTOR', 'ASHOKLEY', 'BOSCHLTD', 'MOTHERSON']
        ];
        
        return $sectors[$sector] ?? $sectors['NIFTY BANK'];
    }
    
    // Dummy data for fallback (when API fails)
    private function getDummyIndexData($index) {
        $dummyData = [
            'NIFTY 50' => ['name' => 'Nifty', 'last' => 25966.05, 'change' => 70.9, 'percentChange' => 0.68],
            'NIFTY BANK' => ['name' => 'Bank Nifty', 'last' => 58114.25, 'change' => 14.05, 'percentChange' => 0.72],
            'SENSEX' => ['name' => 'Sensex', 'last' => 84778.84, 'change' => 566.96, 'percentChange' => 0.67],
            'NIFTY FIN SERVICE' => ['name' => 'Fin Nifty', 'last' => 27519.00, 'change' => 23.7, 'percentChange' => 0.45]
        ];
        
        return $dummyData[$index] ?? ['name' => $index, 'last' => 0, 'change' => 0, 'percentChange' => 0];
    }
    
    private function getDummyStockData($symbol) {
        // Generate random-ish data based on symbol
        $base = crc32($symbol) % 2000 + 100;
        $change = (crc32($symbol . date('H')) % 100 - 50) / 10;
        $pChange = ($change / $base) * 100;
        
        return [
            'symbol' => $symbol,
            'ltp' => round($base + $change, 2),
            'change' => round($change, 2),
            'pChange' => round($pChange, 2),
            'open' => round($base, 2),
            'high' => round($base + abs($change) + 5, 2),
            'low' => round($base - abs($change) - 5, 2),
            'volume' => rand(100, 2000)
        ];
    }
}
?>

