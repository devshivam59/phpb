# Robo Trade Investment Platform

A complete PHP-based trading platform with admin panel for managing users, deposits, withdrawals, and manual trade entries.

## Features

### User Panel
- **Dashboard**: Live market indices (Nifty, Bank Nifty, Sensex, Fin Nifty) with real-time price updates
- **Sector View**: View stocks by sector (NIFTY BANK, NIFTY 50, NIFTY IT, NIFTY ENERGY, NIFTY AUTO)
- **Funds Management**: Deposit and withdrawal requests with UPI integration
- **Positions**: View all trading positions (open and closed) with profit/loss
- **Transaction History**: View deposit and withdrawal history
- **Profile Management**: Update personal and banking information

### Admin Panel
- **Dashboard**: Overview of users, pending deposits/withdrawals, and total trades
- **User Management**: Create, edit, and manage user accounts
- **Deposit Management**: Approve/reject deposit requests and update user balance
- **Withdrawal Management**: Process withdrawal requests
- **Trade Management**: Manually create and close trades for users
- **Activity Logs**: Track all admin actions

## Technology Stack

- **Backend**: PHP 8.x
- **Database**: MySQL 8.0
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **API**: NSE India API for live market data (with fallback dummy data)

## Installation

### Prerequisites
- PHP 8.0 or higher
- MySQL 8.0 or higher
- Apache/Nginx web server
- mod_rewrite enabled (for Apache)

### Step 1: Setup Files
1. Extract the platform files to your web server directory
2. Ensure proper permissions for uploads directory:
   ```bash
   chmod 755 uploads/
   chmod 755 uploads/profiles/
   chmod 755 uploads/payment_proofs/
   ```

### Step 2: Configure Database
1. Open `config/database.php`
2. Update database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'your_db_user');
   define('DB_PASS', 'your_db_password');
   define('DB_NAME', 'robo_trade');
   ```

### Step 3: Run Installation
1. Navigate to `http://yourdomain.com/install.php` in your browser
2. The installation script will:
   - Create the database
   - Create all necessary tables
   - Set up the default admin account
3. **Important**: Delete `install.php` after successful installation

### Step 4: Configure Settings
1. Open `config/config.php`
2. Update UPI payment details:
   ```php
   define('UPI_ID', 'your-upi-id@upi');
   define('UPI_NAME', 'Your Business Name');
   ```
3. Update site URL and other settings as needed

## Default Credentials

### Admin Panel
- **URL**: `http://yourdomain.com/admin/`
- **Admin ID**: `admin001`
- **Password**: `admin123`

**⚠️ Change the default password immediately after first login!**

### User Panel
- **URL**: `http://yourdomain.com/user/`
- Users must be created by admin

## Usage Guide

### For Admin

#### Creating Users
1. Login to admin panel
2. Go to "Users" section
3. Click "Add User"
4. Fill in user details and submit
5. Provide the generated User ID and password to the user

#### Managing Deposits
1. Go to "Deposits" section
2. View pending deposit requests
3. Click "Approve" to add funds to user balance
4. Click "Reject" to decline the request with a reason

#### Managing Withdrawals
1. Go to "Withdrawals" section
2. View pending withdrawal requests
3. Verify user bank details
4. Click "Approve" to process withdrawal (deducts from user balance)
5. Click "Reject" to decline the request

#### Creating Trades
1. Go to "Trades" section
2. Click "Add Trade"
3. Select user, enter symbol, type (BUY/SELL), quantity, and entry price
4. Submit to create the trade
5. To close a trade, click "Close" button and enter exit price

### For Users

#### Making a Deposit
1. Login to user panel
2. Go to "Funds" section
3. Click "Make Deposit"
4. Enter amount and payment details
5. Upload payment screenshot (optional)
6. Submit request and wait for admin approval

#### Requesting Withdrawal
1. Ensure bank details are updated in profile
2. Go to "Funds" section
3. Click "Request Withdrawal"
4. Enter withdrawal amount
5. Submit request and wait for admin approval

#### Viewing Positions
1. Go to "Positions" section
2. View all your trades
3. Filter by "Open" or "Closed" status
4. See profit/loss for closed trades

## API Integration

The platform uses NSE India API for live market data. If the API is unavailable, it falls back to dummy data generation.

### Supported Indices
- NIFTY 50
- NIFTY BANK
- SENSEX
- NIFTY FIN SERVICE

### Supported Sectors
- NIFTY BANK
- NIFTY 50
- NIFTY IT
- NIFTY ENERGY
- NIFTY AUTO

## Security Features

- Password hashing using PHP's `password_hash()`
- SQL injection prevention using prepared statements
- XSS protection through input sanitization
- CSRF token validation for forms
- Role-based access control (Admin/User)
- Session security with httponly cookies

## File Structure

```
robo-trade-platform/
├── config/
│   ├── database.php          # Database configuration
│   ├── config.php            # Application settings
├── includes/
│   ├── functions.php         # Common functions
│   ├── api_handler.php       # Market data API
├── admin/
│   ├── index.php             # Admin login
│   ├── dashboard.php         # Admin dashboard
│   ├── users.php             # User management
│   ├── deposits.php          # Deposit management
│   ├── withdrawals.php       # Withdrawal management
│   ├── trades.php            # Trade management
│   └── includes/             # Admin includes
├── user/
│   ├── index.php             # User login
│   ├── dashboard.php         # User dashboard
│   ├── funds.php             # Funds management
│   ├── positions.php         # View positions
│   ├── profile.php           # Profile management
│   └── includes/             # User includes
├── api/
│   ├── get_indices.php       # Index data API
│   └── get_stock_data.php    # Stock data API
├── assets/
│   ├── css/style.css         # Main stylesheet
│   └── js/dashboard.js       # Dashboard JavaScript
└── uploads/                  # User uploads
```

## Troubleshooting

### Database Connection Error
- Verify database credentials in `config/database.php`
- Ensure MySQL service is running
- Check if database user has proper permissions

### Live Prices Not Updating
- Check browser console for JavaScript errors
- Verify API endpoints are accessible
- The system will use dummy data if API fails

### File Upload Issues
- Check folder permissions (755 for directories)
- Verify `upload_max_filesize` in php.ini
- Ensure `post_max_size` is sufficient

## Maintenance

### Backup
Regular backups recommended:
```bash
# Database backup
mysqldump -u username -p robo_trade > backup.sql

# Files backup
tar -czf uploads_backup.tar.gz uploads/
```

### Updates
- Keep PHP and MySQL updated
- Regularly review admin logs
- Monitor disk space for uploads

## Support

For issues or questions:
- Check the troubleshooting section
- Review error logs in your web server
- Ensure all prerequisites are met

## Security Notes

**Production Deployment:**
1. Change all default passwords
2. Enable HTTPS (SSL certificate)
3. Set `display_errors = 0` in php.ini
4. Use strong database passwords
5. Regularly update PHP and MySQL
6. Implement rate limiting
7. Set up regular backups
8. Monitor admin logs for suspicious activity

## License

This platform is provided as-is for educational and commercial use.

---

**Version**: 1.0.0  
**Last Updated**: October 2025

