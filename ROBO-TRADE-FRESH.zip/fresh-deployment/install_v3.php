<?php
require_once __DIR__ . '/config/database.php';

$success_messages = [];
$error_messages = [];

try {
    $conn = getDBConnection();
    
    // Add new columns to users table
    $columns_to_add = [
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS aadhar_number VARCHAR(12) DEFAULT NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS pan_number VARCHAR(10) DEFAULT NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS address TEXT DEFAULT NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS dob DATE DEFAULT NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS qr_code_image VARCHAR(255) DEFAULT NULL",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS theme_preference ENUM('light', 'dark') DEFAULT 'dark'",
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS design_theme VARCHAR(20) DEFAULT 'default'"
    ];
    
    foreach ($columns_to_add as $sql) {
        try {
            $conn->query($sql);
            $success_messages[] = "Column added/verified";
        } catch (Exception $e) {
            // Column might already exist, that's okay
        }
    }
    
    // Create registration_requests table
    $sql = "CREATE TABLE IF NOT EXISTS registration_requests (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id_requested VARCHAR(50) NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        address TEXT NOT NULL,
        dob DATE NOT NULL,
        pan_number VARCHAR(10) NOT NULL,
        aadhar_number VARCHAR(12) NOT NULL,
        bank_name VARCHAR(255) NOT NULL,
        account_number VARCHAR(50) NOT NULL,
        ifsc_code VARCHAR(20) NOT NULL,
        account_holder_name VARCHAR(100) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        admin_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        processed_at TIMESTAMP NULL,
        processed_by INT,
        UNIQUE KEY unique_email (email),
        UNIQUE KEY unique_phone (phone)
    )";
    
    if ($conn->query($sql)) {
        $success_messages[] = "Registration requests table created/verified";
    }
    
    $conn->close();
    $success_messages[] = "Database updated successfully!";
    
} catch (Exception $e) {
    $error_messages[] = "Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Platform Update v3.0</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 50px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #667eea;
            text-align: center;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 10px;
            margin: 10px 0;
        }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            margin: 10px 5px;
        }
        .info {
            background: #d1ecf1;
            color: #0c5460;
            padding: 15px;
            border-radius: 10px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Platform Update v3.0</h1>
        
        <?php foreach ($success_messages as $msg): ?>
            <div class="success">✓ <?php echo $msg; ?></div>
        <?php endforeach; ?>
        
        <?php foreach ($error_messages as $msg): ?>
            <div class="error">✗ <?php echo $msg; ?></div>
        <?php endforeach; ?>
        
        <div class="info">
            <h3>✨ New Features Added:</h3>
            <ul>
                <li>User self-registration with admin approval</li>
                <li>Enhanced profile with KYC fields (PAN, Aadhaar)</li>
                <li>Personal QR code system for each user</li>
                <li>Theme toggle (Light/Dark mode)</li>
                <li>5 design variations (Default, Ocean, Forest, Sunset, Royal)</li>
                <li>Profile restrictions (users can only edit password & bank details)</li>
                <li>Admin can change user passwords</li>
                <li>Admin can upload custom QR codes for users</li>
            </ul>
        </div>
        
        <div style="text-align: center;">
            <a href="admin/" class="btn">Go to Admin Panel</a>
            <a href="user/" class="btn">Go to User Panel</a>
        </div>
        
        <div class="info" style="margin-top: 20px;">
            <strong>⚠️ Important:</strong> Delete this file (install_v3.php) after installation for security.
        </div>
    </div>
</body>
</html>
