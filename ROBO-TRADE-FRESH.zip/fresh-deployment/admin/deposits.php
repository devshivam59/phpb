<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

$success = '';
$error = '';

// Handle approve/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $deposit_id = intval($_POST['deposit_id']);
    $action = $_POST['action'];
    $admin_note = sanitize($_POST['admin_note'] ?? '');
    
    $conn = getDBConnection();
    
    // Get deposit details
    $stmt = $conn->prepare("SELECT * FROM deposits WHERE id = ?");
    $stmt->bind_param("i", $deposit_id);
    $stmt->execute();
    $deposit = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($deposit) {
        if ($action === 'approve') {
            // Update deposit status
            $stmt = $conn->prepare("UPDATE deposits SET status='approved', approved_at=NOW(), approved_by=?, admin_note=? WHERE id=?");
            $stmt->bind_param("isi", $admin_id, $admin_note, $deposit_id);
            $stmt->execute();
            $stmt->close();
            
            // Add balance to user
            updateUserBalance($deposit['user_id'], $deposit['amount'], 'add');
            
            // Create notification
            createNotification($deposit['user_id'], 'Deposit Approved', 'Your deposit of ' . formatCurrency($deposit['amount']) . ' has been approved.', 'deposit');
            
            // Log action
            logAdminAction($admin_id, 'Approved Deposit', $deposit['user_id'], 'Amount: ' . $deposit['amount']);
            
            $success = 'Deposit approved successfully';
        } elseif ($action === 'reject') {
            // Update deposit status
            $stmt = $conn->prepare("UPDATE deposits SET status='rejected', admin_note=? WHERE id=?");
            $stmt->bind_param("si", $admin_note, $deposit_id);
            $stmt->execute();
            $stmt->close();
            
            // Create notification
            createNotification($deposit['user_id'], 'Deposit Rejected', 'Your deposit of ' . formatCurrency($deposit['amount']) . ' has been rejected. Reason: ' . $admin_note, 'deposit');
            
            // Log action
            logAdminAction($admin_id, 'Rejected Deposit', $deposit['user_id'], 'Amount: ' . $deposit['amount'] . ', Reason: ' . $admin_note);
            
            $success = 'Deposit rejected';
        }
    }
    
    $conn->close();
}

// Get all deposits
$filter = $_GET['filter'] ?? 'all';
$conn = getDBConnection();

$where_clause = "";
if ($filter === 'pending') {
    $where_clause = "WHERE d.status='pending'";
} elseif ($filter === 'approved') {
    $where_clause = "WHERE d.status='approved'";
} elseif ($filter === 'rejected') {
    $where_clause = "WHERE d.status='rejected'";
}

$sql = "SELECT d.*, u.user_id, u.first_name, u.last_name, u.email FROM deposits d 
        JOIN users u ON d.user_id = u.id 
        $where_clause
        ORDER BY d.created_at DESC";
$result = $conn->query($sql);
$deposits = [];
while ($row = $result->fetch_assoc()) {
    $deposits[] = $row;
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposits - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Deposit Management</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Deposits</h2>
                    <div style="display: flex; gap: 10px;">
                        <a href="?filter=all" class="btn btn-sm <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?>">All</a>
                        <a href="?filter=pending" class="btn btn-sm <?php echo $filter === 'pending' ? 'btn-primary' : 'btn-secondary'; ?>">Pending</a>
                        <a href="?filter=approved" class="btn btn-sm <?php echo $filter === 'approved' ? 'btn-primary' : 'btn-secondary'; ?>">Approved</a>
                        <a href="?filter=rejected" class="btn btn-sm <?php echo $filter === 'rejected' ? 'btn-primary' : 'btn-secondary'; ?>">Rejected</a>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Amount</th>
                                <th>UPI ID</th>
                                <th>Transaction ID</th>
                                <th>Screenshot</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($deposits)): ?>
                                <tr><td colspan="9" style="text-align: center;">No deposits found</td></tr>
                            <?php else: ?>
                                <?php foreach ($deposits as $deposit): ?>
                                    <tr>
                                        <td><?php echo $deposit['id']; ?></td>
                                        <td>
                                            <strong><?php echo $deposit['first_name'] . ' ' . $deposit['last_name']; ?></strong><br>
                                            <small style="color: var(--text-secondary);"><?php echo $deposit['user_id']; ?></small>
                                        </td>
                                        <td><strong><?php echo formatCurrency($deposit['amount']); ?></strong></td>
                                        <td><?php echo $deposit['upi_id']; ?></td>
                                        <td><?php echo $deposit['transaction_id']; ?></td>
                                        <td>
                                            <?php if ($deposit['screenshot']): ?>
                                                <a href="../uploads/payment_proofs/<?php echo $deposit['screenshot']; ?>" target="_blank" class="btn btn-sm btn-primary">View</a>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo formatDateTime($deposit['created_at']); ?></td>
                                        <td><span class="status-badge status-<?php echo $deposit['status']; ?>"><?php echo ucfirst($deposit['status']); ?></span></td>
                                        <td>
                                            <?php if ($deposit['status'] === 'pending'): ?>
                                                <button class="btn btn-sm btn-success" onclick="openApproveModal(<?php echo $deposit['id']; ?>)">Approve</button>
                                                <button class="btn btn-sm btn-danger" onclick="openRejectModal(<?php echo $deposit['id']; ?>)">Reject</button>
                                            <?php else: ?>
                                                <?php if ($deposit['admin_note']): ?>
                                                    <small style="color: var(--text-secondary);"><?php echo $deposit['admin_note']; ?></small>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Approve Modal -->
    <div id="approveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Approve Deposit</h2>
                <button class="modal-close" onclick="closeModal('approveModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="deposit_id" id="approve_deposit_id">
                <input type="hidden" name="action" value="approve">
                
                <div class="form-group">
                    <label class="form-label">Admin Note (Optional)</label>
                    <textarea name="admin_note" class="form-control" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-success">Approve Deposit</button>
            </form>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Reject Deposit</h2>
                <button class="modal-close" onclick="closeModal('rejectModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="deposit_id" id="reject_deposit_id">
                <input type="hidden" name="action" value="reject">
                
                <div class="form-group">
                    <label class="form-label">Reason for Rejection *</label>
                    <textarea name="admin_note" class="form-control" rows="3" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-danger">Reject Deposit</button>
            </form>
        </div>
    </div>
    
    <script>
        function openApproveModal(id) {
            document.getElementById('approve_deposit_id').value = id;
            document.getElementById('approveModal').classList.add('active');
        }
        
        function openRejectModal(id) {
            document.getElementById('reject_deposit_id').value = id;
            document.getElementById('rejectModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>

