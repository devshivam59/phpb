<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

$success = '';
$error = '';

// Handle approve/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $withdrawal_id = intval($_POST['withdrawal_id']);
    $action = $_POST['action'];
    $admin_note = sanitize($_POST['admin_note'] ?? '');
    
    $conn = getDBConnection();
    
    // Get withdrawal details
    $stmt = $conn->prepare("SELECT * FROM withdrawals WHERE id = ?");
    $stmt->bind_param("i", $withdrawal_id);
    $stmt->execute();
    $withdrawal = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($withdrawal) {
        if ($action === 'approve') {
            // Check if user has sufficient balance
            $user_balance = getUserBalance($withdrawal['user_id']);
            
            if ($user_balance >= $withdrawal['amount']) {
                // Update withdrawal status
                $stmt = $conn->prepare("UPDATE withdrawals SET status='approved', processed_at=NOW(), processed_by=?, admin_note=? WHERE id=?");
                $stmt->bind_param("isi", $admin_id, $admin_note, $withdrawal_id);
                $stmt->execute();
                $stmt->close();
                
                // Deduct balance from user
                updateUserBalance($withdrawal['user_id'], $withdrawal['amount'], 'subtract');
                
                // Create notification
                createNotification($withdrawal['user_id'], 'Withdrawal Approved', 'Your withdrawal of ' . formatCurrency($withdrawal['amount']) . ' has been approved and processed.', 'withdrawal');
                
                // Log action
                logAdminAction($admin_id, 'Approved Withdrawal', $withdrawal['user_id'], 'Amount: ' . $withdrawal['amount']);
                
                $success = 'Withdrawal approved successfully';
            } else {
                $error = 'User has insufficient balance';
            }
        } elseif ($action === 'reject') {
            // Update withdrawal status
            $stmt = $conn->prepare("UPDATE withdrawals SET status='rejected', admin_note=? WHERE id=?");
            $stmt->bind_param("si", $admin_note, $withdrawal_id);
            $stmt->execute();
            $stmt->close();
            
            // Create notification
            createNotification($withdrawal['user_id'], 'Withdrawal Rejected', 'Your withdrawal of ' . formatCurrency($withdrawal['amount']) . ' has been rejected. Reason: ' . $admin_note, 'withdrawal');
            
            // Log action
            logAdminAction($admin_id, 'Rejected Withdrawal', $withdrawal['user_id'], 'Amount: ' . $withdrawal['amount'] . ', Reason: ' . $admin_note);
            
            $success = 'Withdrawal rejected';
        }
    }
    
    $conn->close();
}

// Get all withdrawals
$filter = $_GET['filter'] ?? 'all';
$conn = getDBConnection();

$where_clause = "";
if ($filter === 'pending') {
    $where_clause = "WHERE w.status='pending'";
} elseif ($filter === 'approved') {
    $where_clause = "WHERE w.status='approved'";
} elseif ($filter === 'rejected') {
    $where_clause = "WHERE w.status='rejected'";
}

$sql = "SELECT w.*, u.user_id, u.first_name, u.last_name, u.email, u.balance FROM withdrawals w 
        JOIN users u ON w.user_id = u.id 
        $where_clause
        ORDER BY w.created_at DESC";
$result = $conn->query($sql);
$withdrawals = [];
while ($row = $result->fetch_assoc()) {
    $withdrawals[] = $row;
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdrawals - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Withdrawal Management</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Withdrawals</h2>
                    <div style="display: flex; gap: 10px;">
                        <a href="?filter=all" class="btn btn-sm <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?>">All</a>
                        <a href="?filter=pending" class="btn btn-sm <?php echo $filter === 'pending' ? 'btn-primary' : 'btn-secondary'; ?>">Pending</a>
                        <a href="?filter=approved" class="btn btn-sm <?php echo $filter === 'approved' ? 'btn-primary' : 'btn-secondary'; ?>">Approved</a>
                        <a href="?filter=rejected" class="btn btn-sm <?php echo $filter === 'rejected' ? 'btn-primary' : 'btn-secondary'; ?>">Rejected</a>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Amount</th>
                                <th>Bank Details</th>
                                <th>User Balance</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($withdrawals)): ?>
                                <tr><td colspan="8" style="text-align: center;">No withdrawals found</td></tr>
                            <?php else: ?>
                                <?php foreach ($withdrawals as $withdrawal): ?>
                                    <tr>
                                        <td><?php echo $withdrawal['id']; ?></td>
                                        <td>
                                            <strong><?php echo $withdrawal['first_name'] . ' ' . $withdrawal['last_name']; ?></strong><br>
                                            <small style="color: var(--text-secondary);"><?php echo $withdrawal['user_id']; ?></small>
                                        </td>
                                        <td><strong><?php echo formatCurrency($withdrawal['amount']); ?></strong></td>
                                        <td>
                                            <strong><?php echo $withdrawal['bank_name']; ?></strong><br>
                                            <small style="color: var(--text-secondary);">
                                                A/C: <?php echo $withdrawal['account_number']; ?><br>
                                                IFSC: <?php echo $withdrawal['ifsc_code']; ?>
                                            </small>
                                        </td>
                                        <td>
                                            <strong class="<?php echo $withdrawal['balance'] >= $withdrawal['amount'] ? 'price-up' : 'price-down'; ?>">
                                                <?php echo formatCurrency($withdrawal['balance']); ?>
                                            </strong>
                                        </td>
                                        <td><?php echo formatDateTime($withdrawal['created_at']); ?></td>
                                        <td><span class="status-badge status-<?php echo $withdrawal['status']; ?>"><?php echo ucfirst($withdrawal['status']); ?></span></td>
                                        <td>
                                            <?php if ($withdrawal['status'] === 'pending'): ?>
                                                <button class="btn btn-sm btn-success" onclick="openApproveModal(<?php echo $withdrawal['id']; ?>, <?php echo $withdrawal['amount']; ?>, <?php echo $withdrawal['balance']; ?>)">Approve</button>
                                                <button class="btn btn-sm btn-danger" onclick="openRejectModal(<?php echo $withdrawal['id']; ?>)">Reject</button>
                                            <?php else: ?>
                                                <?php if ($withdrawal['admin_note']): ?>
                                                    <small style="color: var(--text-secondary);"><?php echo $withdrawal['admin_note']; ?></small>
                                                <?php else: ?>
                                                    -
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Approve Modal -->
    <div id="approveModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Approve Withdrawal</h2>
                <button class="modal-close" onclick="closeModal('approveModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="withdrawal_id" id="approve_withdrawal_id">
                <input type="hidden" name="action" value="approve">
                
                <div class="alert alert-info" id="approve_info"></div>
                
                <div class="form-group">
                    <label class="form-label">Admin Note (Optional)</label>
                    <textarea name="admin_note" class="form-control" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn btn-success">Approve Withdrawal</button>
            </form>
        </div>
    </div>
    
    <!-- Reject Modal -->
    <div id="rejectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Reject Withdrawal</h2>
                <button class="modal-close" onclick="closeModal('rejectModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="withdrawal_id" id="reject_withdrawal_id">
                <input type="hidden" name="action" value="reject">
                
                <div class="form-group">
                    <label class="form-label">Reason for Rejection *</label>
                    <textarea name="admin_note" class="form-control" rows="3" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-danger">Reject Withdrawal</button>
            </form>
        </div>
    </div>
    
    <script>
        function openApproveModal(id, amount, balance) {
            document.getElementById('approve_withdrawal_id').value = id;
            
            let info = 'Withdrawal Amount: ₹' + amount.toFixed(2) + '<br>';
            info += 'User Balance: ₹' + balance.toFixed(2) + '<br>';
            
            if (balance < amount) {
                info += '<span style="color: var(--danger-color);"><strong>⚠️ Insufficient balance!</strong></span>';
            } else {
                info += '<span style="color: var(--success-color);"><strong>✓ Sufficient balance</strong></span>';
            }
            
            document.getElementById('approve_info').innerHTML = info;
            document.getElementById('approveModal').classList.add('active');
        }
        
        function openRejectModal(id) {
            document.getElementById('reject_withdrawal_id').value = id;
            document.getElementById('rejectModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>

