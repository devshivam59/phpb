<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

$success = '';
$error = '';

// Handle add user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_user') {
    $user_id = sanitize($_POST['user_id']);
    $password = $_POST['password'];
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("INSERT INTO users (user_id, password, first_name, last_name, email, phone, role) VALUES (?, ?, ?, ?, ?, ?, 'user')");
    $stmt->bind_param("ssssss", $user_id, $hashed_password, $first_name, $last_name, $email, $phone);
    
    if ($stmt->execute()) {
        logAdminAction($admin_id, 'Created User', $stmt->insert_id, "User ID: $user_id");
        $success = 'User created successfully';
    } else {
        $error = 'Failed to create user: ' . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
}

// Handle update balance
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_balance') {
    $user_id = intval($_POST['user_id']);
    $amount = floatval($_POST['amount']);
    $operation = $_POST['operation'];
    
    if (updateUserBalance($user_id, $amount, $operation)) {
        $user_data = getUserData($user_id);
        logAdminAction($admin_id, 'Updated Balance', $user_id, "Operation: $operation, Amount: $amount");
        createNotification($user_id, 'Balance Updated', 'Your balance has been updated by admin.', 'system');
        $success = 'Balance updated successfully';
    } else {
        $error = 'Failed to update balance';
    }
}

// Handle update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $user_id = intval($_POST['user_id']);
    $status = $_POST['status'];
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("UPDATE users SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $user_id);
    
    if ($stmt->execute()) {
        logAdminAction($admin_id, 'Updated User Status', $user_id, "New status: $status");
        createNotification($user_id, 'Account Status Changed', 'Your account status has been changed to: ' . $status, 'system');
        $success = 'User status updated successfully';
    } else {
        $error = 'Failed to update status';
    }
    
    $stmt->close();
    $conn->close();
}

// Get all users
$conn = getDBConnection();
$result = $conn->query("SELECT * FROM users WHERE role='user' ORDER BY created_at DESC");
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">User Management</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Users</h2>
                    <button class="btn btn-primary" onclick="openAddUserModal()">+ Add User</button>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Balance</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr><td colspan="9" style="text-align: center;">No users found</td></tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo $user['id']; ?></td>
                                        <td><strong><?php echo $user['user_id']; ?></strong></td>
                                        <td><?php echo $user['first_name'] . ' ' . $user['last_name']; ?></td>
                                        <td><?php echo $user['email']; ?></td>
                                        <td><?php echo $user['phone']; ?></td>
                                        <td><strong><?php echo formatCurrency($user['balance']); ?></strong></td>
                                        <td><span class="status-badge status-<?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                        <td><?php echo formatDate($user['created_at']); ?></td>
                                        <td>
                                            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-info"><i class="fas fa-edit"></i> Edit</a>
                                            <button class="btn btn-sm btn-primary" onclick="openBalanceModal(<?php echo $user['id']; ?>, '<?php echo $user['user_id']; ?>', <?php echo $user['balance']; ?>)">Balance</button>
                                            <button class="btn btn-sm btn-warning" onclick="openStatusModal(<?php echo $user['id']; ?>, '<?php echo $user['user_id']; ?>', '<?php echo $user['status']; ?>')">Status</button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add User Modal -->
    <div id="addUserModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New User</h2>
                <button class="modal-close" onclick="closeModal('addUserModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_user">
                
                <div class="form-group">
                    <label class="form-label">User ID *</label>
                    <input type="text" name="user_id" class="form-control" placeholder="e.g., ABC0001234" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                
                <div class="grid grid-2">
                    <div class="form-group">
                        <label class="form-label">First Name *</label>
                        <input type="text" name="first_name" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Last Name *</label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Phone *</label>
                    <input type="tel" name="phone" class="form-control" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Create User</button>
            </form>
        </div>
    </div>
    
    <!-- Update Balance Modal -->
    <div id="balanceModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Balance: <span id="balance_user_id"></span></h2>
                <button class="modal-close" onclick="closeModal('balanceModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_balance">
                <input type="hidden" name="user_id" id="balance_user_id_input">
                
                <div class="alert alert-info">
                    Current Balance: <strong id="current_balance"></strong>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Operation *</label>
                    <select name="operation" class="form-control" required>
                        <option value="add">Add to Balance</option>
                        <option value="subtract">Subtract from Balance</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Amount *</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Balance</button>
            </form>
        </div>
    </div>
    
    <!-- Update Status Modal -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Status: <span id="status_user_id"></span></h2>
                <button class="modal-close" onclick="closeModal('statusModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="user_id" id="status_user_id_input">
                
                <div class="form-group">
                    <label class="form-label">Status *</label>
                    <select name="status" class="form-control" id="status_select" required>
                        <option value="active">Active</option>
                        <option value="suspended">Suspended</option>
                        <option value="blocked">Blocked</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-warning">Update Status</button>
            </form>
        </div>
    </div>
    
    <script>
        function openAddUserModal() {
            document.getElementById('addUserModal').classList.add('active');
        }
        
        function openBalanceModal(id, userId, balance) {
            document.getElementById('balance_user_id_input').value = id;
            document.getElementById('balance_user_id').textContent = userId;
            document.getElementById('current_balance').textContent = '₹' + parseFloat(balance).toFixed(2);
            document.getElementById('balanceModal').classList.add('active');
        }
        
        function openStatusModal(id, userId, currentStatus) {
            document.getElementById('status_user_id_input').value = id;
            document.getElementById('status_user_id').textContent = userId;
            document.getElementById('status_select').value = currentStatus;
            document.getElementById('statusModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>

