<div class="sidebar">
    <div class="sidebar-logo">
        <h2>Admin Panel</h2>
    </div>
    
    <ul class="sidebar-menu">
        <li>
            <a href="dashboard.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
                <span class="icon">📊</span>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="users.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
                <span class="icon"><i class="fas fa-users"></i></span>
                <span>Users</span>
            </a>
        </li>
        <li>
            <a href="registrations.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'registrations.php' ? 'active' : ''; ?>">
                <span class="icon"><i class="fas fa-user-check"></i></span>
                <span>Registrations</span>
            </a>
        </li>
        <li>
            <a href="deposits.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'deposits.php' ? 'active' : ''; ?>">
                <span class="icon">💰</span>
                <span>Deposits</span>
            </a>
        </li>
        <li>
            <a href="withdrawals.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'withdrawals.php' ? 'active' : ''; ?>">
                <span class="icon">🏦</span>
                <span>Withdrawals</span>
            </a>
        </li>
        <li>
            <a href="trades.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'trades.php' ? 'active' : ''; ?>">
                <span class="icon">📈</span>
                <span>Trades</span>
            </a>
        </li>
        <li>
            <a href="settings.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'settings.php' ? 'active' : ''; ?>">
                <span class="icon"><i class="fas fa-cog"></i></span>
                <span>Settings</span>
            </a>
        </li>
        <li>
            <a href="logout.php">
                <span class="icon">🚪</span>
                <span>Logout</span>
            </a>
        </li>
    </ul>
</div>

