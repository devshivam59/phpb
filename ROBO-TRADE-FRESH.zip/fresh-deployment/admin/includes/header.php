<div class="header">
    <div class="header-search">
        <input type="text" placeholder="Search...">
    </div>
    
    <div class="header-actions">
        <div class="user-profile">
            <div class="user-avatar" style="background: var(--danger-color); display: flex; align-items: center; justify-content: center; font-weight: bold;">
                <?php echo strtoupper(substr($admin['first_name'], 0, 1)); ?>
            </div>
            <span><?php echo $admin['first_name']; ?> (Admin)</span>
        </div>
    </div>
</div>

