<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

// Get statistics
$conn = getDBConnection();

// Total users
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='user'");
$total_users = $result->fetch_assoc()['count'];

// Pending deposits
$result = $conn->query("SELECT COUNT(*) as count FROM deposits WHERE status='pending'");
$pending_deposits = $result->fetch_assoc()['count'];

// Pending withdrawals
$result = $conn->query("SELECT COUNT(*) as count FROM withdrawals WHERE status='pending'");
$pending_withdrawals = $result->fetch_assoc()['count'];

// Total trades
$result = $conn->query("SELECT COUNT(*) as count FROM positions");
$total_trades = $result->fetch_assoc()['count'];

// Recent deposits
$recent_deposits = [];
$result = $conn->query("SELECT d.*, u.user_id, u.first_name, u.last_name FROM deposits d 
                        JOIN users u ON d.user_id = u.id 
                        ORDER BY d.created_at DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recent_deposits[] = $row;
}

// Recent withdrawals
$recent_withdrawals = [];
$result = $conn->query("SELECT w.*, u.user_id, u.first_name, u.last_name FROM withdrawals w 
                        JOIN users u ON w.user_id = u.id 
                        ORDER BY w.created_at DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recent_withdrawals[] = $row;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Admin Dashboard</h1>
            
            <!-- Statistics Cards -->
            <div class="grid grid-4">
                <div class="stat-card">
                    <div class="stat-info">
                        <h3><?php echo $total_users; ?></h3>
                        <p>Total Users</p>
                    </div>
                    <div class="stat-icon">👥</div>
                </div>
                
                <div class="stat-card warning">
                    <div class="stat-info">
                        <h3><?php echo $pending_deposits; ?></h3>
                        <p>Pending Deposits</p>
                    </div>
                    <div class="stat-icon">💰</div>
                </div>
                
                <div class="stat-card danger">
                    <div class="stat-info">
                        <h3><?php echo $pending_withdrawals; ?></h3>
                        <p>Pending Withdrawals</p>
                    </div>
                    <div class="stat-icon">🏦</div>
                </div>
                
                <div class="stat-card success">
                    <div class="stat-info">
                        <h3><?php echo $total_trades; ?></h3>
                        <p>Total Trades</p>
                    </div>
                    <div class="stat-icon">📈</div>
                </div>
            </div>
            
            <div class="grid grid-2 mt-20">
                <!-- Recent Deposits -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Recent Deposits</h2>
                        <a href="deposits.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recent_deposits)): ?>
                                    <tr><td colspan="4" style="text-align: center;">No deposits yet</td></tr>
                                <?php else: ?>
                                    <?php foreach ($recent_deposits as $deposit): ?>
                                        <tr>
                                            <td><?php echo $deposit['first_name'] . ' ' . $deposit['last_name']; ?></td>
                                            <td><?php echo formatCurrency($deposit['amount']); ?></td>
                                            <td><span class="status-badge status-<?php echo $deposit['status']; ?>"><?php echo ucfirst($deposit['status']); ?></span></td>
                                            <td><?php echo formatDate($deposit['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Recent Withdrawals -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">Recent Withdrawals</h2>
                        <a href="withdrawals.php" class="btn btn-sm btn-primary">View All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recent_withdrawals)): ?>
                                    <tr><td colspan="4" style="text-align: center;">No withdrawals yet</td></tr>
                                <?php else: ?>
                                    <?php foreach ($recent_withdrawals as $withdrawal): ?>
                                        <tr>
                                            <td><?php echo $withdrawal['first_name'] . ' ' . $withdrawal['last_name']; ?></td>
                                            <td><?php echo formatCurrency($withdrawal['amount']); ?></td>
                                            <td><span class="status-badge status-<?php echo $withdrawal['status']; ?>"><?php echo ucfirst($withdrawal['status']); ?></span></td>
                                            <td><?php echo formatDate($withdrawal['created_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

