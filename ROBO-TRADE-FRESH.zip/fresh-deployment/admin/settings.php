<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('../admin/index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

$success = '';
$error = '';

// Handle QR code upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload_qr') {
    if (isset($_FILES['qr_code']) && $_FILES['qr_code']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['qr_code']['name'];
        $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($filetype, $allowed)) {
            if ($_FILES['qr_code']['size'] < 5000000) { // 5MB
                $new_filename = 'payment_qr_' . time() . '.' . $filetype;
                $upload_path = __DIR__ . '/../uploads/qr_codes/' . $new_filename;
                
                // Create directory if it doesn't exist
                if (!is_dir(__DIR__ . '/../uploads/qr_codes/')) {
                    mkdir(__DIR__ . '/../uploads/qr_codes/', 0755, true);
                }
                
                if (move_uploaded_file($_FILES['qr_code']['tmp_name'], $upload_path)) {
                    $conn = getDBConnection();
                    
                    // Get old QR code to delete
                    $stmt = $conn->prepare("SELECT setting_value FROM admin_settings WHERE setting_key='payment_qr_code'");
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($row = $result->fetch_assoc()) {
                        $old_qr = $row['setting_value'];
                        if ($old_qr && file_exists(__DIR__ . '/../uploads/qr_codes/' . $old_qr)) {
                            unlink(__DIR__ . '/../uploads/qr_codes/' . $old_qr);
                        }
                    }
                    $stmt->close();
                    
                    // Save new QR code
                    $stmt = $conn->prepare("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('payment_qr_code', ?) ON DUPLICATE KEY UPDATE setting_value=?");
                    $stmt->bind_param("ss", $new_filename, $new_filename);
                    if ($stmt->execute()) {
                        $success = 'Payment QR code uploaded successfully! Users will now see this QR code when making deposits.';
                    } else {
                        $error = 'Failed to save QR code to database';
                    }
                    $stmt->close();
                    $conn->close();
                } else {
                    $error = 'Failed to upload QR code';
                }
            } else {
                $error = 'File size must be less than 5MB';
            }
        } else {
            $error = 'Only JPG, PNG, and GIF files are allowed';
        }
    } else {
        $error = 'Please select a file to upload';
    }
}

// Handle UPI details update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_upi') {
    $upi_id = trim($_POST['upi_id']);
    $upi_name = trim($_POST['upi_name']);
    
    if (!empty($upi_id) && !empty($upi_name)) {
        $conn = getDBConnection();
        
        $stmt = $conn->prepare("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('upi_id', ?) ON DUPLICATE KEY UPDATE setting_value=?");
        $stmt->bind_param("ss", $upi_id, $upi_id);
        $stmt->execute();
        $stmt->close();
        
        $stmt = $conn->prepare("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('upi_name', ?) ON DUPLICATE KEY UPDATE setting_value=?");
        $stmt->bind_param("ss", $upi_name, $upi_name);
        $stmt->execute();
        $stmt->close();
        
        $conn->close();
        $success = 'UPI details updated successfully!';
    } else {
        $error = 'Please fill in all UPI details';
    }
}

// Get current settings
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT setting_key, setting_value FROM admin_settings WHERE setting_key IN ('payment_qr_code', 'upi_id', 'upi_name')");
$stmt->execute();
$result = $stmt->get_result();
$settings = [];
while ($row = $result->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$stmt->close();
$conn->close();

$current_qr = $settings['payment_qr_code'] ?? null;
$current_upi_id = $settings['upi_id'] ?? 'payment@robotrade';
$current_upi_name = $settings['upi_name'] ?? 'Robo Trade Platform';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Settings - Admin Panel</title>
    
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="dashboard-container">
        <?php include 'includes/sidebar.php'; ?>
        
        <div class="main-content">
            <div class="page-header">
                <h1><i class="fas fa-cog"></i> Payment Settings</h1>
                <p>Manage payment QR code and UPI details for user deposits</p>
            </div>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Payment QR Code Section -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-qrcode"></i> Payment QR Code</h3>
                    <p style="font-size: 0.9rem; color: var(--text-secondary); margin-top: 5px;">
                        Upload a QR code that users will scan to make UPI payments for deposits
                    </p>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px;">
                        <!-- Current QR Code -->
                        <div>
                            <h4 style="margin-bottom: 15px;">Current QR Code</h4>
                            <?php if ($current_qr && file_exists(__DIR__ . '/../uploads/qr_codes/' . $current_qr)): ?>
                                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px; border: 2px solid #e9ecef;">
                                    <img src="../uploads/qr_codes/<?php echo $current_qr; ?>" alt="Payment QR Code" style="max-width: 300px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                    <p style="margin-top: 15px; color: #28a745; font-weight: 600;">
                                        <i class="fas fa-check-circle"></i> QR Code Active
                                    </p>
                                    <p style="font-size: 0.85rem; color: var(--text-secondary);">
                                        Users will see this QR code when making deposits
                                    </p>
                                </div>
                            <?php else: ?>
                                <div style="text-align: center; padding: 40px; background: #fff3cd; border-radius: 10px; border: 2px dashed #ffc107;">
                                    <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #ffc107; margin-bottom: 15px;"></i>
                                    <p style="font-weight: 600; color: #856404;">No QR Code Uploaded</p>
                                    <p style="font-size: 0.9rem; color: #856404;">
                                        Users will only see UPI ID and name until you upload a QR code
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Upload New QR Code -->
                        <div>
                            <h4 style="margin-bottom: 15px;">Upload New QR Code</h4>
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="upload_qr">
                                
                                <div class="form-group">
                                    <label><i class="fas fa-image"></i> Select QR Code Image</label>
                                    <input type="file" name="qr_code" class="form-control" accept="image/*" required>
                                    <small style="color: var(--text-secondary);">
                                        <i class="fas fa-info-circle"></i> Max 5MB, JPG/PNG/GIF format
                                    </small>
                                </div>

                                <div style="background: #e7f3ff; padding: 15px; border-radius: 8px; border-left: 4px solid #2196f3; margin-bottom: 20px;">
                                    <p style="margin: 0; font-size: 0.9rem; color: #0c5460;">
                                        <i class="fas fa-lightbulb"></i> <strong>Tip:</strong> Generate your UPI QR code from any UPI app (Google Pay, PhonePe, Paytm, etc.) and upload it here.
                                    </p>
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-upload"></i> Upload QR Code
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- UPI Details Section -->
            <div class="card" style="margin-top: 20px;">
                <div class="card-header">
                    <h3><i class="fas fa-mobile-alt"></i> UPI Payment Details</h3>
                    <p style="font-size: 0.9rem; color: var(--text-secondary); margin-top: 5px;">
                        These details will be shown to users if QR code is not available
                    </p>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_upi">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div class="form-group">
                                <label><i class="fas fa-at"></i> UPI ID</label>
                                <input type="text" name="upi_id" class="form-control" value="<?php echo htmlspecialchars($current_upi_id); ?>" placeholder="yourname@upi" required>
                                <small style="color: var(--text-secondary);">
                                    Example: 9876543210@paytm
                                </small>
                            </div>

                            <div class="form-group">
                                <label><i class="fas fa-user"></i> Account Holder Name</label>
                                <input type="text" name="upi_name" class="form-control" value="<?php echo htmlspecialchars($current_upi_name); ?>" placeholder="Your Name" required>
                                <small style="color: var(--text-secondary);">
                                    Name registered with UPI
                                </small>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save"></i> Save UPI Details
                        </button>
                    </form>
                </div>
            </div>

            <!-- Instructions -->
            <div class="card" style="margin-top: 20px;">
                <div class="card-header">
                    <h3><i class="fas fa-question-circle"></i> How to Generate UPI QR Code</h3>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
                        <div style="padding: 20px; background: #f8f9fa; border-radius: 10px; text-align: center;">
                            <div style="width: 50px; height: 50px; background: #4CAF50; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
                                <i class="fas fa-mobile-alt" style="color: white; font-size: 1.5rem;"></i>
                            </div>
                            <h4 style="margin-bottom: 10px;">Step 1</h4>
                            <p style="font-size: 0.9rem; color: var(--text-secondary);">
                                Open your UPI app (Google Pay, PhonePe, Paytm, etc.)
                            </p>
                        </div>

                        <div style="padding: 20px; background: #f8f9fa; border-radius: 10px; text-align: center;">
                            <div style="width: 50px; height: 50px; background: #2196F3; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
                                <i class="fas fa-qrcode" style="color: white; font-size: 1.5rem;"></i>
                            </div>
                            <h4 style="margin-bottom: 10px;">Step 2</h4>
                            <p style="font-size: 0.9rem; color: var(--text-secondary);">
                                Go to "Receive Money" or "My QR Code" section
                            </p>
                        </div>

                        <div style="padding: 20px; background: #f8f9fa; border-radius: 10px; text-align: center;">
                            <div style="width: 50px; height: 50px; background: #FF9800; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px;">
                                <i class="fas fa-download" style="color: white; font-size: 1.5rem;"></i>
                            </div>
                            <h4 style="margin-bottom: 10px;">Step 3</h4>
                            <p style="font-size: 0.9rem; color: var(--text-secondary);">
                                Save/Download the QR code and upload it here
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>
