<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('../admin/index.php');

$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$success = '';
$error = '';

$conn = getDBConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'update_profile') {
            $first_name = sanitize($_POST['first_name']);
            $last_name = sanitize($_POST['last_name']);
            $email = sanitize($_POST['email']);
            $phone = sanitize($_POST['phone']);
            $address = sanitize($_POST['address']);
            $dob = $_POST['dob'];
            $pan_number = strtoupper(sanitize($_POST['pan_number']));
            $aadhar_number = sanitize($_POST['aadhar_number']);
            $status = $_POST['status'];
            
            $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, email=?, phone=?, address=?, dob=?, pan_number=?, aadhar_number=?, status=? WHERE id=?");
            $stmt->bind_param("sssssssssi", $first_name, $last_name, $email, $phone, $address, $dob, $pan_number, $aadhar_number, $status, $user_id);
            
            if ($stmt->execute()) {
                $success = 'Profile updated successfully';
            } else {
                $error = 'Failed to update profile';
            }
            $stmt->close();
        }
        
        elseif ($_POST['action'] === 'update_bank') {
            $bank_name = sanitize($_POST['bank_name']);
            $account_number = sanitize($_POST['account_number']);
            $ifsc_code = strtoupper(sanitize($_POST['ifsc_code']));
            $account_holder_name = sanitize($_POST['account_holder_name']);
            
            $stmt = $conn->prepare("UPDATE users SET bank_name=?, account_number=?, ifsc_code=?, account_holder_name=? WHERE id=?");
            $stmt->bind_param("ssssi", $bank_name, $account_number, $ifsc_code, $account_holder_name, $user_id);
            
            if ($stmt->execute()) {
                $success = 'Bank details updated successfully';
            } else {
                $error = 'Failed to update bank details';
            }
            $stmt->close();
        }
        
        elseif ($_POST['action'] === 'change_password') {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (strlen($new_password) < 6) {
                $error = 'Password must be at least 6 characters';
            } elseif ($new_password !== $confirm_password) {
                $error = 'Passwords do not match';
            } else {
                $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param("si", $password_hash, $user_id);
                
                if ($stmt->execute()) {
                    $success = 'Password changed successfully';
                } else {
                    $error = 'Failed to change password';
                }
                $stmt->close();
            }
        }
        
        elseif ($_POST['action'] === 'update_balance') {
            $new_balance = (float)$_POST['balance'];
            
            // Get current balance
            $stmt = $conn->prepare("SELECT balance FROM users WHERE id=?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $current_balance = $result->fetch_assoc()['balance'];
            $stmt->close();
            
            // Calculate difference
            $difference = $new_balance - $current_balance;
            
            // Update balance
            $stmt = $conn->prepare("UPDATE users SET balance=? WHERE id=?");
            $stmt->bind_param("di", $new_balance, $user_id);
            
            if ($stmt->execute()) {
                // Log transaction
                $type = $difference >= 0 ? 'admin_credit' : 'admin_debit';
                $amount = abs($difference);
                $description = $difference >= 0 ? 'Balance credited by admin' : 'Balance debited by admin';
                
                $stmt = $conn->prepare("INSERT INTO transactions (user_id, type, amount, description) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isds", $user_id, $type, $amount, $description);
                $stmt->execute();
                $stmt->close();
                
                $success = 'Balance updated successfully';
            } else {
                $error = 'Failed to update balance';
            }
            $stmt->close();
        }
        
        elseif ($_POST['action'] === 'upload_qr') {
            if (isset($_FILES['qr_code']) && $_FILES['qr_code']['error'] === 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif'];
                $filename = $_FILES['qr_code']['name'];
                $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                
                if (in_array($filetype, $allowed)) {
                    if ($_FILES['qr_code']['size'] < 5000000) {
                        $new_filename = 'qr_user_' . $user_id . '_' . time() . '.' . $filetype;
                        $upload_path = __DIR__ . '/../uploads/qr_codes/' . $new_filename;
                        
                        if (move_uploaded_file($_FILES['qr_code']['tmp_name'], $upload_path)) {
                            // Delete old QR if exists
                            $stmt = $conn->prepare("SELECT qr_code_image FROM users WHERE id=?");
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $old_qr = $stmt->get_result()->fetch_assoc()['qr_code_image'];
                            if ($old_qr && file_exists(__DIR__ . '/../uploads/qr_codes/' . $old_qr)) {
                                unlink(__DIR__ . '/../uploads/qr_codes/' . $old_qr);
                            }
                            $stmt->close();
                            
                            $stmt = $conn->prepare("UPDATE users SET qr_code_image=? WHERE id=?");
                            $stmt->bind_param("si", $new_filename, $user_id);
                            if ($stmt->execute()) {
                                $success = 'QR code uploaded successfully';
                            }
                            $stmt->close();
                        } else {
                            $error = 'Failed to upload QR code';
                        }
                    } else {
                        $error = 'File size must be less than 5MB';
                    }
                } else {
                    $error = 'Only JPG, JPEG, PNG & GIF files are allowed';
                }
            }
        }
    }
}

// Get user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();
$conn->close();

if (!$user) {
    redirect('users.php');
}

include __DIR__ . '/includes/header.php';
?>

<div class="main-content">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    
    <div class="content">
        <div class="page-header">
            <h1><i class="fas fa-user-edit"></i> Edit User: <?php echo $user['first_name'] . ' ' . $user['last_name']; ?></h1>
            <a href="users.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back to Users</a>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <!-- Left Column -->
            <div>
                <!-- Personal Information -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user"></i> Personal Information</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_profile">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>First Name *</label>
                                    <input type="text" name="first_name" class="form-control" value="<?php echo $user['first_name']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Last Name *</label>
                                    <input type="text" name="last_name" class="form-control" value="<?php echo $user['last_name']; ?>" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Email *</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo $user['email']; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Phone *</label>
                                    <input type="tel" name="phone" class="form-control" value="<?php echo $user['phone']; ?>" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Date of Birth</label>
                                <input type="date" name="dob" class="form-control" value="<?php echo $user['dob']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <textarea name="address" class="form-control" rows="3"><?php echo $user['address']; ?></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label>PAN Number</label>
                                    <input type="text" name="pan_number" class="form-control" value="<?php echo $user['pan_number']; ?>" maxlength="10">
                                </div>
                                <div class="form-group">
                                    <label>Aadhaar Number</label>
                                    <input type="text" name="aadhar_number" class="form-control" value="<?php echo $user['aadhar_number']; ?>" maxlength="12">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Status *</label>
                                <select name="status" class="form-control" required>
                                    <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                    <option value="suspended" <?php echo $user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                                    <option value="blocked" <?php echo $user['status'] === 'blocked' ? 'selected' : ''; ?>>Blocked</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Profile</button>
                        </form>
                    </div>
                </div>

                <!-- Bank Details -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header">
                        <h3><i class="fas fa-university"></i> Bank Details</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_bank">
                            <div class="form-group">
                                <label>Account Holder Name</label>
                                <input type="text" name="account_holder_name" class="form-control" value="<?php echo $user['account_holder_name']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Bank Name</label>
                                <input type="text" name="bank_name" class="form-control" value="<?php echo $user['bank_name']; ?>">
                            </div>
                            <div class="form-group">
                                <label>Account Number</label>
                                <input type="text" name="account_number" class="form-control" value="<?php echo $user['account_number']; ?>">
                            </div>
                            <div class="form-group">
                                <label>IFSC Code</label>
                                <input type="text" name="ifsc_code" class="form-control" value="<?php echo $user['ifsc_code']; ?>" maxlength="11">
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Bank Details</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Right Column -->
            <div>
                <!-- Change Password -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-key"></i> Change Password</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="change_password">
                            <div class="form-group">
                                <label>New Password *</label>
                                <input type="password" name="new_password" class="form-control" minlength="6" required>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password *</label>
                                <input type="password" name="confirm_password" class="form-control" minlength="6" required>
                            </div>
                            <button type="submit" class="btn btn-warning"><i class="fas fa-key"></i> Change Password</button>
                        </form>
                    </div>
                </div>

                <!-- Update Balance -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header">
                        <h3><i class="fas fa-wallet"></i> Update Balance</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="action" value="update_balance">
                            <div class="form-group">
                                <label>Current Balance</label>
                                <input type="number" step="0.01" name="balance" class="form-control" value="<?php echo $user['balance']; ?>" required>
                            </div>
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Update Balance</button>
                        </form>
                    </div>
                </div>

                <!-- Upload QR Code -->
                <div class="card" style="margin-top: 20px;">
                    <div class="card-header">
                        <h3><i class="fas fa-qrcode"></i> Payment QR Code</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($user['qr_code_image']): ?>
                            <div style="text-align: center; margin-bottom: 15px;">
                                <img src="../uploads/qr_codes/<?php echo $user['qr_code_image']; ?>" alt="QR Code" style="max-width: 200px; border: 2px solid #ddd; border-radius: 10px;">
                            </div>
                        <?php endif; ?>
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="upload_qr">
                            <div class="form-group">
                                <label>Upload New QR Code</label>
                                <input type="file" name="qr_code" class="form-control" accept="image/*" required>
                                <small style="color: var(--text-secondary);">Max 5MB, JPG/PNG/GIF</small>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload QR Code</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
