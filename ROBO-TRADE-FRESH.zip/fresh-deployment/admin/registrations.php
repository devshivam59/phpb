<?php
require_once __DIR__ . '/../includes/functions.php';
if (!isLoggedIn() || !isAdmin()) redirect('../admin/index.php');

$admin_id = $_SESSION['user_id'];

// Fetch admin details for header
$conn_admin = getDBConnection();
$stmt_admin = $conn_admin->prepare("SELECT * FROM users WHERE id = ?");
$stmt_admin->bind_param("i", $admin_id);
$stmt_admin->execute();
$admin = $stmt_admin->get_result()->fetch_assoc();
$stmt_admin->close();
$conn_admin->close();
$success = '';
$error = '';

// Get a single database connection for the entire script
$conn = getDBConnection();

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $request_id = (int)$_POST['request_id'];
    
    if ($_POST['action'] === 'approve') {
        // Get registration request
        $stmt = $conn->prepare("SELECT * FROM registration_requests WHERE id=? AND status='pending'");
        $stmt->bind_param("i", $request_id);
        $stmt->execute();
        $request = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if ($request) {
            // Create user account
            $stmt = $conn->prepare("INSERT INTO users 
                (user_id, password, first_name, last_name, email, phone, address, dob, pan_card, 
                 bank_name, account_number, ifsc_code, role, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'user', 'active')");
            $stmt->bind_param("ssssssssssss",
                $request['user_id_requested'], $request['password_hash'], $request['first_name'], 
                $request['last_name'], $request['email'], $request['phone'], $request['address'], 
                $request['dob'], $request['pan_number'], 
                $request['bank_name'], $request['account_number'], $request['ifsc_code']);
            
            if ($stmt->execute()) {
                // Update request status
                $stmt = $conn->prepare("UPDATE registration_requests SET status='approved' WHERE id=?");
                $stmt->bind_param("i", $request_id);
                $stmt->execute();
                $success = 'Registration approved successfully! User ID: ' . $request['user_id_requested'];
            } else {
                $error = 'Failed to create user account';
            }
            $stmt->close();
        }
    } elseif ($_POST['action'] === 'reject') {
        $stmt = $conn->prepare("UPDATE registration_requests SET status='rejected' WHERE id=?");
        $stmt->bind_param("i", $request_id);
        if ($stmt->execute()) {
            $success = 'Registration rejected';
        }
        $stmt->close();
    }
}

// Get all registration requests
$pending_requests = $conn->query("SELECT * FROM registration_requests WHERE status='pending' ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);
$processed_requests = $conn->query("SELECT * FROM registration_requests WHERE status IN ('approved', 'rejected') ORDER BY created_at DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);

// Close connection before including HTML
$conn->close();

include __DIR__ . '/includes/header.php';
?>

<div class="main-content">
    <?php include __DIR__ . '/includes/sidebar.php'; ?>
    
    <div class="content">
        <div class="page-header">
            <h1><i class="fas fa-user-check"></i> Registration Requests</h1>
        </div>

        <?php if ($success): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Pending Requests -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-clock"></i> Pending Requests (<?php echo count($pending_requests); ?>)</h3>
            </div>
            <div class="card-body">
                <?php if (empty($pending_requests)): ?>
                    <p style="text-align: center; color: var(--text-secondary); padding: 20px;">No pending registration requests</p>
                <?php else: ?>
                    <?php foreach ($pending_requests as $req): ?>
                        <div class="request-card" style="background: rgba(255,255,255,0.05); padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.1);">
                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                                <div>
                                    <h4 style="margin-bottom: 5px;"><?php echo $req['first_name'] . ' ' . $req['last_name']; ?></h4>
                                    <p style="color: var(--text-secondary); font-size: 0.9rem;">
                                        <i class="fas fa-id-badge"></i> Requested ID: <strong><?php echo $req['user_id_requested']; ?></strong>
                                    </p>
                                    <p style="color: var(--text-secondary); font-size: 0.85rem;">
                                        <i class="fas fa-clock"></i> <?php echo date('d M Y, h:i A', strtotime($req['created_at'])); ?>
                                    </p>
                                </div>
                                <div>
                                    <button class="btn btn-sm btn-primary" onclick="viewDetails(<?php echo $req['id']; ?>)">
                                        <i class="fas fa-eye"></i> View Details
                                    </button>
                                </div>
                            </div>
                            
                            <div id="details-<?php echo $req['id']; ?>" style="display: none; margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.1);">
                                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 15px;">
                                    <div>
                                        <strong>Email:</strong> <?php echo $req['email']; ?><br>
                                        <strong>Phone:</strong> <?php echo $req['phone']; ?><br>
                                        <strong>DOB:</strong> <?php echo date('d M Y', strtotime($req['dob'])); ?>
                                    </div>
                                    <div>
                                        <strong>PAN:</strong> <?php echo $req['pan_number']; ?><br>
                                        <strong>Aadhaar:</strong> <?php echo $req['aadhar_number']; ?>
                                    </div>
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <strong>Address:</strong><br>
                                    <?php echo nl2br($req['address']); ?>
                                </div>
                                <div style="margin-bottom: 15px;">
                                    <strong>Bank Details:</strong><br>
                                    <?php echo $req['bank_name']; ?> | A/C: <?php echo $req['account_number']; ?> | IFSC: <?php echo $req['ifsc_code']; ?><br>
                                    Holder: <?php echo $req['account_holder_name']; ?>
                                </div>
                                
                                <div style="display: flex; gap: 10px;">
                                    <form method="POST" style="flex: 1;">
                                        <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="btn btn-success" style="width: 100%;" onclick="return confirm('Approve this registration?')">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    </form>
                                    <form method="POST" style="flex: 1;">
                                        <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                        <input type="hidden" name="action" value="reject">
                                        <button type="submit" class="btn btn-danger" style="width: 100%;" onclick="return confirm('Reject this registration?')">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Processed Requests -->
        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3><i class="fas fa-history"></i> Recent Processed Requests</h3>
            </div>
            <div class="card-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>User ID</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($processed_requests as $req): ?>
                            <tr>
                                <td><?php echo $req['first_name'] . ' ' . $req['last_name']; ?></td>
                                <td><?php echo $req['user_id_requested']; ?></td>
                                <td><?php echo $req['email']; ?></td>
                                <td><?php echo $req['phone']; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $req['status']; ?>">
                                        <?php echo ucfirst($req['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d M Y', strtotime($req['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function viewDetails(id) {
    const details = document.getElementById('details-' + id);
    details.style.display = details.style.display === 'none' ? 'block' : 'none';
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
