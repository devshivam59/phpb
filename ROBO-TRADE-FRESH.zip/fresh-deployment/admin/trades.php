<?php
require_once __DIR__ . '/../includes/functions.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('index.php');
}

$admin_id = $_SESSION['user_id'];
$admin = getUserData($admin_id);

$success = '';
$error = '';

// Handle add trade
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_trade') {
    $user_id = intval($_POST['user_id']);
    $symbol = strtoupper(sanitize($_POST['symbol']));
    $trade_type = $_POST['trade_type'];
    $quantity = intval($_POST['quantity']);
    $entry_price = floatval($_POST['entry_price']);
    $entry_date = $_POST['entry_date'];
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("INSERT INTO positions (user_id, symbol, trade_type, quantity, entry_price, entry_date, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issidsi", $user_id, $symbol, $trade_type, $quantity, $entry_price, $entry_date, $admin_id);
    
    if ($stmt->execute()) {
        createNotification($user_id, 'New Trade', 'A new ' . strtoupper($trade_type) . ' trade for ' . $symbol . ' has been added to your account.', 'trade');
        logAdminAction($admin_id, 'Added Trade', $user_id, "Symbol: $symbol, Type: $trade_type, Qty: $quantity, Price: $entry_price");
        $success = 'Trade added successfully';
    } else {
        $error = 'Failed to add trade';
    }
    
    $stmt->close();
    $conn->close();
}

// Handle close trade
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'close_trade') {
    $trade_id = intval($_POST['trade_id']);
    $exit_price = floatval($_POST['exit_price']);
    $exit_date = $_POST['exit_date'];
    
    $conn = getDBConnection();
    
    // Get trade details
    $stmt = $conn->prepare("SELECT * FROM positions WHERE id = ?");
    $stmt->bind_param("i", $trade_id);
    $stmt->execute();
    $trade = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($trade) {
        // Calculate profit/loss
        $profit_loss = calculateProfitLoss($trade['trade_type'], $trade['entry_price'], $exit_price, $trade['quantity']);
        
        // Update trade
        $stmt = $conn->prepare("UPDATE positions SET exit_price=?, exit_date=?, profit_loss=?, status='closed' WHERE id=?");
        $stmt->bind_param("dsdi", $exit_price, $exit_date, $profit_loss, $trade_id);
        
        if ($stmt->execute()) {
            createNotification($trade['user_id'], 'Trade Closed', 'Your ' . $trade['symbol'] . ' trade has been closed with P/L: ' . formatCurrency($profit_loss), 'trade');
            logAdminAction($admin_id, 'Closed Trade', $trade['user_id'], "Symbol: {$trade['symbol']}, P/L: $profit_loss");
            $success = 'Trade closed successfully';
        } else {
            $error = 'Failed to close trade';
        }
        
        $stmt->close();
    }
    
    $conn->close();
}

// Get all trades
$filter = $_GET['filter'] ?? 'all';
$conn = getDBConnection();

$where_clause = "";
if ($filter === 'open') {
    $where_clause = "WHERE p.status='open'";
} elseif ($filter === 'closed') {
    $where_clause = "WHERE p.status='closed'";
}

$sql = "SELECT p.*, u.user_id, u.first_name, u.last_name FROM positions p 
        JOIN users u ON p.user_id = u.id 
        $where_clause
        ORDER BY p.created_at DESC";
$result = $conn->query($sql);
$trades = [];
while ($row = $result->fetch_assoc()) {
    $trades[] = $row;
}

// Get all users for dropdown
$users = [];
$result = $conn->query("SELECT id, user_id, first_name, last_name FROM users WHERE role='user' ORDER BY first_name");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trades - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include 'includes/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include 'includes/header.php'; ?>
        
        <div class="content">
            <h1 class="page-title">Trade Management</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">All Trades</h2>
                    <div style="display: flex; gap: 10px;">
                        <button class="btn btn-primary" onclick="openAddTradeModal()">+ Add Trade</button>
                        <a href="?filter=all" class="btn btn-sm <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?>">All</a>
                        <a href="?filter=open" class="btn btn-sm <?php echo $filter === 'open' ? 'btn-primary' : 'btn-secondary'; ?>">Open</a>
                        <a href="?filter=closed" class="btn btn-sm <?php echo $filter === 'closed' ? 'btn-primary' : 'btn-secondary'; ?>">Closed</a>
                    </div>
                </div>
                
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Symbol</th>
                                <th>Type</th>
                                <th>Qty</th>
                                <th>Entry Price</th>
                                <th>Exit Price</th>
                                <th>Entry Date</th>
                                <th>Exit Date</th>
                                <th>P/L</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($trades)): ?>
                                <tr><td colspan="12" style="text-align: center;">No trades found</td></tr>
                            <?php else: ?>
                                <?php foreach ($trades as $trade): ?>
                                    <tr>
                                        <td><?php echo $trade['id']; ?></td>
                                        <td>
                                            <strong><?php echo $trade['first_name'] . ' ' . $trade['last_name']; ?></strong><br>
                                            <small style="color: var(--text-secondary);"><?php echo $trade['user_id']; ?></small>
                                        </td>
                                        <td><strong><?php echo $trade['symbol']; ?></strong></td>
                                        <td>
                                            <span class="status-badge <?php echo $trade['trade_type'] === 'buy' ? 'status-active' : 'status-rejected'; ?>">
                                                <?php echo strtoupper($trade['trade_type']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $trade['quantity']; ?></td>
                                        <td><?php echo formatCurrency($trade['entry_price']); ?></td>
                                        <td><?php echo $trade['exit_price'] ? formatCurrency($trade['exit_price']) : '-'; ?></td>
                                        <td><?php echo formatDateTime($trade['entry_date']); ?></td>
                                        <td><?php echo $trade['exit_date'] ? formatDateTime($trade['exit_date']) : '-'; ?></td>
                                        <td>
                                            <?php if ($trade['profit_loss'] !== null): ?>
                                                <span class="<?php echo $trade['profit_loss'] >= 0 ? 'price-up' : 'price-down'; ?>">
                                                    <?php echo formatCurrency($trade['profit_loss']); ?>
                                                </span>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="status-badge status-<?php echo $trade['status']; ?>"><?php echo ucfirst($trade['status']); ?></span></td>
                                        <td>
                                            <?php if ($trade['status'] === 'open'): ?>
                                                <button class="btn btn-sm btn-warning" onclick="openCloseTradeModal(<?php echo $trade['id']; ?>, '<?php echo $trade['symbol']; ?>')">Close</button>
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Add Trade Modal -->
    <div id="addTradeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Trade</h2>
                <button class="modal-close" onclick="closeModal('addTradeModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="add_trade">
                
                <div class="form-group">
                    <label class="form-label">Select User *</label>
                    <select name="user_id" class="form-control" required>
                        <option value="">-- Select User --</option>
                        <?php foreach ($users as $u): ?>
                            <option value="<?php echo $u['id']; ?>"><?php echo $u['first_name'] . ' ' . $u['last_name']; ?> (<?php echo $u['user_id']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Symbol *</label>
                    <input type="text" name="symbol" class="form-control" placeholder="e.g., RELIANCE, TCS" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Trade Type *</label>
                    <select name="trade_type" class="form-control" required>
                        <option value="buy">BUY</option>
                        <option value="sell">SELL</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Quantity *</label>
                    <input type="number" name="quantity" class="form-control" min="1" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Entry Price *</label>
                    <input type="number" name="entry_price" class="form-control" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Entry Date *</label>
                    <input type="datetime-local" name="entry_date" class="form-control" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Trade</button>
            </form>
        </div>
    </div>
    
    <!-- Close Trade Modal -->
    <div id="closeTradeModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Close Trade: <span id="close_trade_symbol"></span></h2>
                <button class="modal-close" onclick="closeModal('closeTradeModal')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="close_trade">
                <input type="hidden" name="trade_id" id="close_trade_id">
                
                <div class="form-group">
                    <label class="form-label">Exit Price *</label>
                    <input type="number" name="exit_price" class="form-control" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Exit Date *</label>
                    <input type="datetime-local" name="exit_date" class="form-control" value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-warning">Close Trade</button>
            </form>
        </div>
    </div>
    
    <script>
        function openAddTradeModal() {
            document.getElementById('addTradeModal').classList.add('active');
        }
        
        function openCloseTradeModal(id, symbol) {
            document.getElementById('close_trade_id').value = id;
            document.getElementById('close_trade_symbol').textContent = symbol;
            document.getElementById('closeTradeModal').classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
</body>
</html>

